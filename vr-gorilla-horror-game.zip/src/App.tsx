import { useCallback, useEffect, useRef, useState } from 'react'
import { Game, type Difficulty, type GameConfig, type HudState, type Mode } from './game/Game'
import type { MapKind } from './game/maps'

const MAPS: { id: MapKind; name: string; blurb: string; grad: string; icon: string }[] = [
  { id: 'ship', name: 'Alien Mothership', blurb: 'Cryo pods, glowing eggs and a xenomorph-gorilla with acid veins.', grad: 'from-cyan-900 via-teal-950 to-slate-950', icon: '🛸' },
  { id: 'mansion', name: 'Haunted Mansion', blurb: 'Candlelit halls, lightning and a possessed chained silverback.', grad: 'from-red-950 via-purple-950 to-black', icon: '🏚️' },
  { id: 'backrooms', name: 'The Backrooms', blurb: 'Endless yellow rooms, buzzing lights. Something is wrong with it.', grad: 'from-yellow-800 via-yellow-950 to-stone-950', icon: '🟨' },
]

const MODES: { id: Mode; name: string; blurb: string; icon: string; color: string }[] = [
  { id: 'monster', name: 'Be the Monster', blurb: 'You are the beast. Hunt down 6 survivor gorillas in 4 minutes. Rip them apart.', icon: '👹', color: 'border-red-500' },
  { id: 'survive', name: 'Survive the AI Monster', blurb: 'An AI monster hunts you. Find 4 power cells, open the exit, escape alive.', icon: '🦍', color: 'border-cyan-400' },
]

const FURS = [0xe8742a, 0x3b82f6, 0xec4899, 0x22c55e, 0xa855f7, 0xfacc15, 0xf1f5f9, 0x8b5a2b]
const hex = (n: number) => '#' + n.toString(16).padStart(6, '0')

export default function App() {
  const boxRef = useRef<HTMLDivElement>(null)
  const gameRef = useRef<Game | null>(null)
  const [hud, setHud] = useState<HudState | null>(null)
  const [mode, setMode] = useState<Mode>('survive')
  const [map, setMap] = useState<MapKind>('mansion')
  const [diff, setDiff] = useState<Difficulty>('normal')
  const [gore, setGore] = useState(true)
  const [fur, setFur] = useState(FURS[0])
  const [vrOk, setVrOk] = useState(false)
  const [vrMsg, setVrMsg] = useState('')

  useEffect(() => {
    if (!boxRef.current) return
    const g = new Game(boxRef.current, setHud)
    gameRef.current = g
    ;(window as unknown as { __game: Game }).__game = g
    return () => {
      g.destroy()
      gameRef.current = null
    }
  }, [])

  useEffect(() => {
    gameRef.current?.setShowcaseMap(map)
  }, [map])

  useEffect(() => {
    const xr = (navigator as Navigator & { xr?: { isSessionSupported: (m: string) => Promise<boolean> } }).xr
    xr?.isSessionSupported('immersive-vr').then(setVrOk).catch(() => setVrOk(false))
  }, [])

  const cfg = useCallback((): GameConfig => ({ mode, map, difficulty: diff, gore, fur }), [mode, map, diff, gore, fur])

  const playDesktop = () => {
    gameRef.current?.start(cfg())
    gameRef.current?.renderer.domElement.focus()
  }
  const playVR = async () => {
    const g = gameRef.current
    if (!g) return
    g.start(cfg())
    const ok = await g.enterVR()
    if (!ok) {
      setVrMsg('Could not start a VR session. Make sure your headset browser allows WebXR (HTTPS).')
      g.exitToMenu()
    }
  }

  const playing = hud && hud.phase !== 'menu'
  const isMonster = hud?.mode === 'monster'
  const mm = (s: number) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`

  return (
    <div className="fixed inset-0 overflow-hidden bg-black text-white select-none" style={{ fontFamily: 'Impact, Haettenschweiler, "Arial Narrow Bold", sans-serif' }}>
      <div ref={boxRef} className="absolute inset-0" />

      {/* ---------------- MENU ---------------- */}
      {!playing && (
        <div className="absolute inset-0 overflow-y-auto bg-gradient-to-r from-black/90 via-black/60 to-transparent">
          <div className="max-w-xl p-5 sm:p-8 space-y-5 font-sans">
            <div>
              <div className="text-xs tracking-[0.4em] text-red-500 font-bold">VR · DESKTOP · GORE</div>
              <h1 className="text-5xl sm:text-6xl leading-none tracking-wide text-red-600 drop-shadow-[0_0_18px_rgba(255,0,0,0.5)]" style={{ fontFamily: 'Impact, Haettenschweiler, sans-serif' }}>
                GORILLA<br />
                <span className="text-white">NIGHTMARE</span>
              </h1>
              <p className="text-sm text-zinc-400 mt-2">Gorilla-tag arm-swing movement. Three horror maps. Monsters made of fur, fangs and regret.</p>
            </div>

            <section>
              <h2 className="text-xs font-bold tracking-widest text-zinc-400 mb-2">1 · GAME MODE</h2>
              <div className="grid sm:grid-cols-2 gap-2">
                {MODES.map((m) => (
                  <button key={m.id} onClick={() => setMode(m.id)} className={`text-left rounded-lg border-2 p-3 transition bg-zinc-950/80 hover:bg-zinc-900 ${mode === m.id ? m.color + ' shadow-[0_0_20px_rgba(255,255,255,0.12)]' : 'border-zinc-800'}`}>
                    <div className="text-2xl">{m.icon}</div>
                    <div className="font-bold">{m.name}</div>
                    <div className="text-xs text-zinc-400 mt-1">{m.blurb}</div>
                  </button>
                ))}
              </div>
            </section>

            <section>
              <h2 className="text-xs font-bold tracking-widest text-zinc-400 mb-2">2 · MAP</h2>
              <div className="grid grid-cols-3 gap-2">
                {MAPS.map((m) => (
                  <button key={m.id} onClick={() => setMap(m.id)} className={`rounded-lg border-2 p-2 text-left bg-gradient-to-br ${m.grad} transition ${map === m.id ? 'border-white' : 'border-transparent opacity-70 hover:opacity-100'}`}>
                    <div className="text-2xl">{m.icon}</div>
                    <div className="font-bold text-sm leading-tight">{m.name}</div>
                  </button>
                ))}
              </div>
              <p className="text-xs text-zinc-400 mt-2">{MAPS.find((m) => m.id === map)?.blurb}</p>
            </section>

            <section className="grid grid-cols-2 gap-4">
              <div>
                <h2 className="text-xs font-bold tracking-widest text-zinc-400 mb-2">3 · DIFFICULTY</h2>
                <div className="flex gap-1">
                  {(['easy', 'normal', 'nightmare'] as Difficulty[]).map((d) => (
                    <button key={d} onClick={() => setDiff(d)} className={`px-2 py-1.5 rounded text-xs font-bold uppercase flex-1 ${diff === d ? 'bg-red-600 text-white' : 'bg-zinc-800 text-zinc-300 hover:bg-zinc-700'}`}>
                      {d}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <h2 className="text-xs font-bold tracking-widest text-zinc-400 mb-2">GORE</h2>
                <button onClick={() => setGore(!gore)} className={`px-3 py-1.5 rounded text-xs font-bold w-full ${gore ? 'bg-red-700 text-white' : 'bg-zinc-800 text-zinc-300'}`}>
                  {gore ? '🩸 GORE: ON' : 'GORE: OFF'}
                </button>
              </div>
            </section>

            <section>
              <h2 className="text-xs font-bold tracking-widest text-zinc-400 mb-2">YOUR FUR {mode === 'monster' && <span className="text-red-400">(monster mode overrides)</span>}</h2>
              <div className="flex gap-2 flex-wrap">
                {FURS.map((f) => (
                  <button key={f} onClick={() => setFur(f)} className={`w-8 h-8 rounded-full border-2 ${fur === f ? 'border-white scale-110' : 'border-zinc-700'}`} style={{ background: hex(f) }} aria-label="fur colour" />
                ))}
              </div>
            </section>

            <div className="flex gap-3 flex-wrap">
              <button onClick={playDesktop} className="flex-1 min-w-40 py-3 rounded-lg bg-red-600 hover:bg-red-500 font-black text-lg tracking-widest shadow-[0_0_25px_rgba(255,0,0,0.4)]">
                ▶ PLAY
              </button>
              <button onClick={playVR} disabled={!vrOk} className="flex-1 min-w-40 py-3 rounded-lg bg-cyan-600 hover:bg-cyan-500 disabled:bg-zinc-800 disabled:text-zinc-500 font-black text-lg tracking-widest">
                🥽 ENTER VR
              </button>
            </div>
            {!vrOk && <p className="text-xs text-zinc-500">VR headset not detected — open this page in a Quest / WebXR browser to enable VR. Desktop play uses simulated arm-swinging.</p>}
            {vrMsg && <p className="text-xs text-red-400">{vrMsg}</p>}

            <details className="text-xs text-zinc-300 bg-zinc-950/70 rounded-lg p-3 border border-zinc-800">
              <summary className="cursor-pointer font-bold tracking-wider">CONTROLS</summary>
              <div className="mt-2 space-y-2">
                <p><b className="text-cyan-300">VR:</b> swing your arms and push off the floor, walls & ceiling with your hands — just like Gorilla Tag. Right stick = snap turn · A = hop · Trigger = roar (monster) · hold both grips = menu. Left wrist shows your HUD.</p>
                <p><b className="text-red-300">Desktop:</b> Mouse look (click to capture) · WASD paddle your hands · Shift sprint · Space jump · <b>E / Left-click</b> lunge · <b>F / Right-click</b> roar · Arrow keys also look · R restart.</p>
                <p className="text-zinc-500">All other gorillas are AI bots — there is no online multiplayer.</p>
              </div>
            </details>
          </div>
        </div>
      )}

      {/* ---------------- HUD ---------------- */}
      {playing && hud && !hud.vr && (
        <>
          <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-white/60 pointer-events-none" />
          <div className="absolute top-3 left-3 space-y-1 font-sans pointer-events-none">
            <div className={`px-3 py-1.5 rounded bg-black/60 border ${isMonster ? 'border-red-500' : 'border-cyan-400'} text-sm font-bold`}>
              {isMonster ? (
                <>
                  👹 MONSTER · ⏱ {mm(hud.timeLeft)} · Prey {hud.botsAlive}/{hud.botsTotal}
                </>
              ) : (
                <>
                  🔋 Cells {hud.cells}/{hud.cellsTotal} · {hud.exitOpen ? <span className="text-green-400">EXIT OPEN</span> : 'Find the cells'} · ⏱ {mm(hud.time)}
                </>
              )}
            </div>
            {!isMonster && hud.intro > 0 && <div className="px-3 py-1 rounded bg-red-950/80 text-red-300 text-xs font-bold">Monster wakes in {Math.ceil(hud.intro)}s…</div>}
            {isMonster && (
              <div className="px-3 py-1 rounded bg-black/60 text-xs">{hud.senseCd > 0 ? `Roar cooldown ${Math.ceil(hud.senseCd)}s` : 'Roar ready — press F / right-click to reveal prey'}</div>
            )}
          </div>
          <div className="absolute top-3 right-3 space-y-1 text-right font-sans pointer-events-none">
            {hud.feed.map((f, i) => (
              <div key={i} className="px-2 py-1 rounded bg-black/60 text-xs text-red-300">{f}</div>
            ))}
          </div>
          {hud.message && (
            <div className="absolute top-16 left-1/2 -translate-x-1/2 px-5 py-2 rounded bg-black/70 border border-white/20 text-center font-sans font-bold text-sm sm:text-base max-w-[90vw] pointer-events-none">{hud.message}</div>
          )}
          {!isMonster && hud.danger > 0.25 && hud.phase === 'playing' && (
            <div className="absolute inset-0 pointer-events-none" style={{ boxShadow: `inset 0 0 ${60 + hud.danger * 160}px rgba(200,0,0,${hud.danger * 0.7})` }} />
          )}
          {!hud.locked && hud.phase === 'playing' && (
            <div className="absolute bottom-6 left-1/2 -translate-x-1/2 px-4 py-2 rounded bg-black/70 text-sm font-sans">Click the game to capture the mouse · WASD to move · Shift to sprint · Space to jump</div>
          )}
          <button onClick={() => gameRef.current?.exitToMenu()} className="absolute bottom-3 right-3 px-3 py-1 rounded bg-zinc-900/80 text-xs font-sans hover:bg-zinc-800">☰ Menu</button>

          {(hud.phase === 'won' || hud.phase === 'lost') && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/55 font-sans">
              <div className={`text-center p-8 rounded-xl border-2 bg-black/80 max-w-md ${hud.phase === 'won' ? 'border-green-500' : 'border-red-600'}`}>
                <h2 className={`text-4xl font-black tracking-wider ${hud.phase === 'won' ? 'text-green-400' : 'text-red-500'}`} style={{ fontFamily: 'Impact, sans-serif' }}>{hud.title}</h2>
                <p className="text-zinc-300 mt-3 text-sm">{hud.subtitle}</p>
                {isMonster && <p className="text-red-300 mt-2 text-sm font-bold">Kills: {hud.kills}</p>}
                <div className="flex gap-3 mt-6 justify-center">
                  <button onClick={() => gameRef.current?.restart()} className="px-5 py-2 rounded bg-red-600 hover:bg-red-500 font-bold">↻ Play again (R)</button>
                  <button onClick={() => gameRef.current?.exitToMenu()} className="px-5 py-2 rounded bg-zinc-800 hover:bg-zinc-700 font-bold">Menu</button>
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  )
}
