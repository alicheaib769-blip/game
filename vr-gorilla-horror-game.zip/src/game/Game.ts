import * as THREE from 'three'
import { buildMap, type GameMap, type MapKind } from './maps'
import { Gorilla, Limb, furMaterial, makeNameTag, type MonsterVariant } from './gorilla'
import { GoreSystem } from './gore'
import { AudioSys } from './audio'
import type { P2 } from './nav'

export type Mode = 'monster' | 'survive'
export type Difficulty = 'easy' | 'normal' | 'nightmare'
export interface GameConfig {
  mode: Mode
  map: MapKind
  difficulty: Difficulty
  gore: boolean
  fur: number
}
export interface HudState {
  phase: 'menu' | 'playing' | 'won' | 'lost'
  mode: Mode
  map: MapKind
  time: number
  timeLeft: number
  cells: number
  cellsTotal: number
  exitOpen: boolean
  kills: number
  botsAlive: number
  botsTotal: number
  botsEscaped: number
  message: string
  senseCd: number
  danger: number
  vr: boolean
  locked: boolean
  feed: string[]
  title: string
  subtitle: string
  intro: number
}

const DIFF = {
  easy: { chase: 4.0, patrol: 2.6, flee: 3.7, hear: 0.8 },
  normal: { chase: 5.0, patrol: 3.0, flee: 4.5, hear: 1.0 },
  nightmare: { chase: 6.1, patrol: 3.5, flee: 5.1, hear: 1.35 },
}

const GRAV = 9.5
const HAND_R = 0.1
const HEAD_R = 0.22
const EYE = 1.15
const MONSTER_TIME = 240

const BOT_COLORS = [0xe8742a, 0x3b82f6, 0xec4899, 0x22c55e, 0xa855f7, 0xfacc15, 0xf1f5f9, 0x8b5a2b, 0x06b6d4]
const BOT_NAMES = ['Bongo', 'Kiko', 'Zippy', 'Mango', 'Rumble', 'Pogo', 'Tango', 'Nibbles', 'Chunk', 'Bubba']

interface Agent {
  id: number
  name: string
  kind: 'bot' | 'monster'
  g: Gorilla
  x: number
  z: number
  yaw: number
  path: P2[]
  repath: number
  alive: boolean
  state: 'idle' | 'wander' | 'flee' | 'patrol' | 'chase' | 'search' | 'intro'
  stateT: number
  lastKnown: P2 | null
  aura?: THREE.Mesh
  tag?: THREE.Sprite
  hitCd: number
  stepAcc: number
  curSpeed: number
  color: number
}

interface Panel {
  mesh: THREE.Mesh
  ctx: CanvasRenderingContext2D
  tex: THREE.CanvasTexture
  w: number
  h: number
}

function lerpAngle(a: number, b: number, t: number) {
  let d = ((b - a + Math.PI) % (Math.PI * 2)) - Math.PI
  if (d < -Math.PI) d += Math.PI * 2
  return a + d * t
}

export class Game {
  renderer: THREE.WebGLRenderer
  scene = new THREE.Scene()
  menuScene = new THREE.Scene()
  menuCam = new THREE.PerspectiveCamera(40, 1, 0.1, 60)
  camera = new THREE.PerspectiveCamera(75, 1, 0.03, 120)
  rig = new THREE.Group()
  grips: THREE.Group[] = []
  audio = new AudioSys()
  gore = new GoreSystem()
  clock = new THREE.Clock()

  map: GameMap | null = null
  cfg: GameConfig | null = null
  phase: HudState['phase'] = 'menu'
  isVR = false
  time = 0
  kills = 0
  cellsGot = 0
  escaped = 0
  botsTotal = 0
  message = ''
  messageT = 0
  feed: { t: number; text: string }[] = []
  senseT = 0
  senseCd = 0
  endT = 0
  title = ''
  subtitle = ''
  introT = 0
  danger = 0
  flash = 0
  hudAcc = 0
  heartAcc = 0
  growlAcc = 8

  // player physics
  vel = new THREE.Vector3()
  headRel = new THREE.Vector3()
  handRel = [new THREE.Vector3(), new THREE.Vector3()]
  lastHandRel = [new THREE.Vector3(), new THREE.Vector3()]
  handVis = [new THREE.Vector3(), new THREE.Vector3()]
  prevHandVis = [new THREE.Vector3(), new THREE.Vector3()]
  handSpeed = [0, 0]
  headW = new THREE.Vector3()
  touching = [false, false]
  wasTouching = false
  velHist: THREE.Vector3[] = []
  noContactT = 0
  skipMove = true
  frozen = false
  rigSpeed = 0
  speedMult = 1
  armL: Limb | null = null
  armR: Limb | null = null
  headLight = new THREE.PointLight(0xffffff, 10, 10, 2)
  flashQuad: THREE.Mesh
  flashEl: HTMLDivElement

  // desktop input
  keys = new Set<string>()
  yaw = 0
  pitch = 0
  locked = false
  attackReq = false
  senseReq = false
  jumpReq = false
  cyc = 0
  curDir = new THREE.Vector3(0, 0, -1)
  lookDrag = false
  swinging = [false, false]
  deathRoll = 0
  attackAnim = 0

  // vr input
  snapLatch = false
  trigPrev = [false, false]
  gripHeld = 0
  vrTrig = [false, false]

  agents: Agent[] = []
  monster: Agent | null = null
  cellObjs: { g: THREE.Group; taken: boolean; p: P2; phase: number }[] = []
  free: P2[] = []
  nextId = 1

  // panels
  wrist: Panel
  endPanel: Panel
  wristAcc = 0

  // menu showcase
  showcase: { g: Gorilla; t: number }[] = []
  showcaseMon: Record<string, Gorilla> = {}
  showcaseSurv: Gorilla
  showcaseT = 0

  private tmp = new THREE.Vector3()
  private tmp2 = new THREE.Vector3()
  private push = new THREE.Vector3()
  private disposers: (() => void)[] = []
  private ro: ResizeObserver

  constructor(public container: HTMLElement, public onHud: (h: HudState) => void) {
    const r = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' })
    this.renderer = r
    r.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75))
    r.xr.enabled = true
    r.xr.setReferenceSpaceType('local-floor')
    try {
      r.xr.setFoveation(1)
    } catch {
      /* */
    }
    r.domElement.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;display:block;outline:none'
    r.domElement.tabIndex = 0
    container.appendChild(r.domElement)

    this.flashEl = document.createElement('div')
    this.flashEl.style.cssText =
      'position:absolute;inset:0;pointer-events:none;opacity:0;background:radial-gradient(ellipse at center, rgba(120,0,0,0.15) 0%, rgba(110,0,0,0.65) 60%, rgba(60,0,0,0.95) 100%);mix-blend-mode:normal'
    container.appendChild(this.flashEl)

    // rig
    this.scene.add(this.rig)
    this.rig.add(this.camera)
    this.scene.add(this.headLight)
    for (let i = 0; i < 2; i++) {
      const grip = r.xr.getControllerGrip(i)
      grip.userData.hand = i === 0 ? 'left' : 'right'
      grip.addEventListener('connected', (e: unknown) => {
        const ev = e as { data?: XRInputSource }
        if (ev.data?.handedness) grip.userData.hand = ev.data.handedness
        this.attachWrist()
      })
      this.rig.add(grip)
      this.grips.push(grip)
    }
    this.flashQuad = new THREE.Mesh(
      new THREE.PlaneGeometry(3, 3),
      new THREE.MeshBasicMaterial({ color: 0x7a0000, transparent: true, opacity: 0, depthTest: false, depthWrite: false }),
    )
    this.flashQuad.position.z = -0.25
    this.flashQuad.renderOrder = 999
    this.camera.add(this.flashQuad)

    this.wrist = this.makePanel(0.2, 0.13, 512, 332)
    this.wrist.mesh.rotation.x = -Math.PI / 2 + 0.35
    this.wrist.mesh.position.set(0, 0.05, 0.03)
    this.endPanel = this.makePanel(1.5, 0.95, 768, 486)
    this.endPanel.mesh.position.set(0, 0, -1.5)
    this.endPanel.mesh.visible = false
    this.camera.add(this.endPanel.mesh)

    // showcase scene
    this.menuScene.background = new THREE.Color(0x07090d)
    this.menuScene.fog = new THREE.FogExp2(0x07090d, 0.06)
    this.menuScene.add(new THREE.AmbientLight(0x8890b0, 1.4))
    const key = new THREE.PointLight(0xffd8a0, 45, 20, 2)
    key.position.set(-2, 4, 4)
    const rim = new THREE.PointLight(0xff3030, 40, 20, 2)
    rim.position.set(4.5, 2.5, -2.5)
    this.menuScene.add(key, rim)
    const fl = new THREE.Mesh(new THREE.CircleGeometry(8, 40), new THREE.MeshStandardMaterial({ color: 0x15181f, roughness: 0.9 }))
    fl.rotation.x = -Math.PI / 2
    this.menuScene.add(fl)
    const variants: MonsterVariant[] = ['possessed', 'entity', 'xeno']
    variants.forEach((v) => {
      const g = new Gorilla({ fur: 0, monster: v })
      g.root.position.set(2.3, 0, -0.7)
      g.root.rotation.y = -0.5
      g.root.visible = false
      this.menuScene.add(g.root)
      this.showcaseMon[v] = g
      this.showcase.push({ g, t: Math.random() * 5 })
    })
    this.showcaseMon.possessed.root.visible = true
    this.showcaseSurv = new Gorilla({ fur: 0xe8742a, belly: 0xf5b27a, accent: 0x3b82f6, cosmetic: 4 })
    this.showcaseSurv.root.position.set(0.3, 0, 0.9)
    this.showcaseSurv.root.rotation.y = 0.5
    this.menuScene.add(this.showcaseSurv.root)
    const sc2 = new Gorilla({ fur: 0x3b82f6, belly: 0x9cc2ff, accent: 0xfacc15, cosmetic: 3 })
    sc2.root.position.set(-1.0, 0, 0.1)
    sc2.root.rotation.y = 0.9
    sc2.root.scale.setScalar(0.92)
    this.menuScene.add(sc2.root)
    this.showcase.push({ g: sc2, t: 2 }, { g: this.showcaseSurv, t: 0 })
    this.menuCam.position.set(0.5, 1.55, 5.6)
    this.menuCam.lookAt(0.6, 1.15, 0)

    this.bindInput()
    this.ro = new ResizeObserver(() => this.resize())
    this.ro.observe(container)
    this.resize()
    r.xr.addEventListener('sessionstart', () => {
      this.isVR = true
      this.rig.rotation.y = this.yaw
      this.skipMove = true
      this.emitHud()
    })
    r.xr.addEventListener('sessionend', () => {
      this.isVR = false
      this.yaw = this.rig.rotation.y
      this.rig.rotation.y = 0
      this.camera.position.set(0, EYE, 0)
      this.skipMove = true
      this.emitHud()
    })
    r.setAnimationLoop(() => this.tick())
  }

  // ---------------------------------------------------------------- setup
  setShowcaseMap(kind: MapKind) {
    const v: MonsterVariant = kind === 'backrooms' ? 'entity' : kind === 'mansion' ? 'possessed' : 'xeno'
    Object.entries(this.showcaseMon).forEach(([k, g]) => (g.root.visible = k === v))
  }

  private resize() {
    const w = this.container.clientWidth || 800
    const h = this.container.clientHeight || 600
    this.renderer.setSize(w, h, false)
    this.camera.aspect = w / h
    this.camera.updateProjectionMatrix()
    this.menuCam.aspect = w / h
    this.menuCam.updateProjectionMatrix()
  }

  private makePanel(w: number, h: number, pw: number, ph: number): Panel {
    const c = document.createElement('canvas')
    c.width = pw
    c.height = ph
    const ctx = c.getContext('2d')!
    const tex = new THREE.CanvasTexture(c)
    tex.colorSpace = THREE.SRGBColorSpace
    const mesh = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ map: tex, transparent: true, depthTest: false }))
    mesh.renderOrder = 998
    return { mesh, ctx, tex, w: pw, h: ph }
  }

  private attachWrist() {
    const left = this.grips.find((g) => g.userData.hand === 'left')
    if (left && this.wrist.mesh.parent !== left) left.add(this.wrist.mesh)
  }

  private bindInput() {
    const el = this.renderer.domElement
    const kd = (e: KeyboardEvent) => {
      if (this.phase === 'menu') return
      this.keys.add(e.code)
      if (e.code === 'Space') {
        this.jumpReq = true
        e.preventDefault()
      }
      if (e.code === 'KeyE') this.attackReq = true
      if (e.code === 'KeyF') this.senseReq = true
      if (e.code === 'KeyR' && this.phase !== 'playing') this.restart()
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) e.preventDefault()
    }
    const ku = (e: KeyboardEvent) => this.keys.delete(e.code)
    const mm = (e: MouseEvent) => {
      if (this.isVR || this.phase !== 'playing') return
      if (this.locked || this.lookDrag) {
        this.yaw -= e.movementX * 0.0024
        this.pitch = Math.max(-1.45, Math.min(1.45, this.pitch - e.movementY * 0.0024))
      }
    }
    const md = (e: MouseEvent) => {
      if (this.isVR || this.phase === 'menu') return
      if (!this.locked) {
        el.requestPointerLock?.()
        this.lookDrag = true
        setTimeout(() => {
          if (document.pointerLockElement === el) this.lookDrag = false
        }, 150)
      } else if (e.button === 0) this.attackReq = true
      else if (e.button === 2) this.senseReq = true
    }
    const mu = () => (this.lookDrag = false)
    const plc = () => {
      this.locked = document.pointerLockElement === el
      this.emitHud()
    }
    const ctx = (e: Event) => e.preventDefault()
    window.addEventListener('keydown', kd)
    window.addEventListener('keyup', ku)
    window.addEventListener('mousemove', mm)
    el.addEventListener('mousedown', md)
    window.addEventListener('mouseup', mu)
    el.addEventListener('contextmenu', ctx)
    document.addEventListener('pointerlockchange', plc)
    this.disposers.push(() => {
      window.removeEventListener('keydown', kd)
      window.removeEventListener('keyup', ku)
      window.removeEventListener('mousemove', mm)
      el.removeEventListener('mousedown', md)
      window.removeEventListener('mouseup', mu)
      el.removeEventListener('contextmenu', ctx)
      document.removeEventListener('pointerlockchange', plc)
    })
  }

  async enterVR(): Promise<boolean> {
    const xr = (navigator as Navigator & { xr?: XRSystem }).xr
    if (!xr) return false
    try {
      const session = await xr.requestSession('immersive-vr', { optionalFeatures: ['local-floor', 'bounded-floor'] })
      await this.renderer.xr.setSession(session)
      return true
    } catch (e) {
      console.warn('VR failed', e)
      return false
    }
  }

  exitVR() {
    const s = this.renderer.xr.getSession()
    if (s) s.end().catch(() => undefined)
  }

  destroy() {
    this.renderer.setAnimationLoop(null)
    this.disposers.forEach((d) => d())
    this.ro.disconnect()
    this.audio.stopAmbient()
    this.renderer.dispose()
    this.renderer.domElement.remove()
    this.flashEl.remove()
  }

  // ---------------------------------------------------------------- world lifecycle
  private clearWorld() {
    if (this.map) {
      this.scene.remove(this.map.group)
      this.map.dispose()
      this.map = null
    }
    this.agents.forEach((a) => this.scene.remove(a.g.root))
    this.agents = []
    this.monster = null
    this.cellObjs.forEach((c) => this.scene.remove(c.g))
    this.cellObjs = []
    if (this.armL) this.scene.remove(this.armL.group)
    if (this.armR) this.scene.remove(this.armR.group)
    this.armL = this.armR = null
    this.scene.remove(this.gore.group)
  }

  start(cfg: GameConfig) {
    this.clearWorld()
    this.cfg = cfg
    this.audio.init()
    const map = buildMap(cfg.map)
    this.map = map
    this.scene.add(map.group)
    this.scene.background = new THREE.Color(map.fogColor)
    this.scene.fog = new THREE.FogExp2(map.fogColor, map.fogDensity)
    this.headLight.color.setHex(map.headLight.color)
    this.headLight.intensity = map.headLight.intensity
    this.headLight.distance = map.headLight.distance
    this.gore.setNav(map.nav)
    this.gore.enabled = cfg.gore
    this.gore.clear()
    this.scene.add(this.gore.group)
    this.free = map.nav.freeCells()
    map.setExitOpen(false)
    map.exitGroup.visible = cfg.mode === 'survive'

    const monsterMode = cfg.mode === 'monster'
    this.speedMult = monsterMode ? 1.32 : 1.0

    // player arms
    const furMat = monsterMode ? furMaterial(0x15101a) : furMaterial(cfg.fur)
    const skin = new THREE.MeshStandardMaterial({ color: monsterMode ? 0x3a3340 : 0x2a2224, roughness: 0.6 })
    const claws = monsterMode ? new THREE.MeshStandardMaterial({ color: 0xe0d8c0, roughness: 0.4 }) : undefined
    this.armL = new Limb(furMat, skin, 0.85, 0.85, 0.15, claws)
    this.armR = new Limb(furMat, skin, 0.85, 0.85, 0.15, claws)
    this.scene.add(this.armL.group, this.armR.group)

    // spawn player
    const spawn = monsterMode ? map.monsterSpawn : map.playerSpawn
    this.rig.position.set(spawn.x, 0.05, spawn.z)
    const cx = (map.nav.W * 4) / 2 - spawn.x
    const cz = (map.nav.H * 4) / 2 - spawn.z
    const yaw = Math.atan2(-cx, -cz)
    if (this.isVR) this.rig.rotation.y = yaw
    else {
      this.yaw = yaw
      this.pitch = -0.1
    }
    this.vel.set(0, 0, 0)
    this.velHist = []
    this.skipMove = true
    this.frozen = false
    this.deathRoll = 0
    this.noContactT = 0
    this.cyc = 0

    // agents
    this.nextId = 1
    this.kills = 0
    this.cellsGot = 0
    this.escaped = 0
    this.time = 0
    this.senseT = 0
    this.senseCd = 0
    this.message = ''
    this.messageT = 0
    this.feed = []
    this.danger = 0
    this.flash = 0
    this.endT = 0
    this.endPanel.mesh.visible = false
    this.introT = monsterMode ? 0 : 7

    const nBots = monsterMode ? 6 : 4
    this.botsTotal = nBots
    const used: P2[] = []
    const spawns = [...map.botSpawns].sort(() => Math.random() - 0.5)
    for (let i = 0; i < nBots; i++) {
      let p = spawns[i]
      if (!p) {
        const far = this.free.filter((c) => Math.hypot(c.x - spawn.x, c.z - spawn.z) > 24 && used.every((u) => Math.hypot(u.x - c.x, u.z - c.z) > 8))
        p = far[Math.floor(Math.random() * far.length)] ?? map.nav.randomFree()
      }
      used.push(p)
      this.spawnBot(p, i)
    }
    if (!monsterMode) {
      this.spawnMonster(map.monsterSpawn, map.variant)
      // cells
      map.cells.forEach((p, i) => {
        if (i >= 4) return
        this.addCell(p, i)
      })
    }
    this.phase = 'playing'
    this.title = ''
    this.subtitle = ''
    this.audio.startAmbient(cfg.map)
    this.setMessage(
      monsterMode ? 'You are the MONSTER. Hunt every survivor before time runs out!' : 'Find 4 power cells, open the exit and ESCAPE. The monster is waking up...',
      6,
    )
    this.emitHud()
  }

  restart() {
    if (this.cfg) this.start(this.cfg)
  }

  exitToMenu() {
    this.clearWorld()
    this.audio.stopAmbient()
    this.phase = 'menu'
    this.endPanel.mesh.visible = false
    this.flash = 0
    this.exitVR()
    if (document.pointerLockElement) document.exitPointerLock()
    this.scene.background = new THREE.Color(0x000000)
    this.emitHud()
  }

  private setMessage(t: string, dur = 4) {
    this.message = t
    this.messageT = dur
  }
  private addFeed(text: string) {
    this.feed.push({ t: this.time, text })
    if (this.feed.length > 5) this.feed.shift()
  }

  private spawnBot(p: P2, i: number) {
    const color = BOT_COLORS[(i + Math.floor(Math.random() * 3)) % BOT_COLORS.length]
    const c = new THREE.Color(color)
    const belly = c.clone().lerp(new THREE.Color(0xffffff), 0.45).getHex()
    const accent = BOT_COLORS[(i * 2 + 3) % BOT_COLORS.length]
    const g = new Gorilla({ fur: color, belly, accent, cosmetic: i % 5 })
    g.root.position.set(p.x, 0, p.z)
    this.scene.add(g.root)
    const name = BOT_NAMES[i % BOT_NAMES.length]
    const tag = makeNameTag(name, '#' + c.getHexString())
    tag.position.set(0, 2.15, 0)
    g.root.add(tag)
    const aura = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.6, 0.9, 4, 10),
      new THREE.MeshBasicMaterial({ color: 0xff2a2a, transparent: true, opacity: 0.4, depthTest: false, depthWrite: false }),
    )
    aura.position.y = 1.0
    aura.renderOrder = 20
    aura.visible = false
    g.root.add(aura)
    const a: Agent = {
      id: this.nextId++, name, kind: 'bot', g, x: p.x, z: p.z, yaw: Math.random() * 6.28, path: [], repath: Math.random(), alive: true,
      state: 'idle', stateT: Math.random() * 2, lastKnown: null, aura, tag, hitCd: 0, stepAcc: 0, curSpeed: 0, color,
    }
    this.agents.push(a)
  }

  private spawnMonster(p: P2, v: MonsterVariant) {
    const g = new Gorilla({ fur: 0, monster: v })
    g.root.position.set(p.x, 0, p.z)
    this.scene.add(g.root)
    const a: Agent = {
      id: this.nextId++, name: 'Monster', kind: 'monster', g, x: p.x, z: p.z, yaw: 0, path: [], repath: 0, alive: true,
      state: 'intro', stateT: 0, lastKnown: null, hitCd: 0, stepAcc: 0, curSpeed: 0, color: 0xff0000,
    }
    this.agents.push(a)
    this.monster = a
  }

  private addCell(p: P2, i: number) {
    const g = new THREE.Group()
    g.position.set(p.x, 1.0, p.z)
    const body = new THREE.Mesh(new THREE.CylinderGeometry(0.17, 0.17, 0.5, 14), new THREE.MeshBasicMaterial({ color: 0xfff060 }))
    const capM = new THREE.MeshStandardMaterial({ color: 0x333a44, metalness: 0.8, roughness: 0.3 })
    const c1 = new THREE.Mesh(new THREE.CylinderGeometry(0.19, 0.19, 0.08, 14), capM)
    c1.position.y = 0.27
    const c2 = c1.clone()
    c2.position.y = -0.27
    const nub = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.07, 10), capM)
    nub.position.y = 0.33
    const beam = new THREE.Mesh(
      new THREE.CylinderGeometry(0.06, 0.06, 4, 8, 1, true),
      new THREE.MeshBasicMaterial({ color: 0xfff060, transparent: true, opacity: 0.22, depthWrite: false }),
    )
    const halo = new THREE.Mesh(
      new THREE.SphereGeometry(0.42, 14, 10),
      new THREE.MeshBasicMaterial({ color: 0xffee55, transparent: true, opacity: 0.18, depthWrite: false }),
    )
    g.add(body, c1, c2, nub, beam, halo)
    this.scene.add(g)
    this.cellObjs.push({ g, taken: false, p, phase: i * 1.7 })
  }

  // ---------------------------------------------------------------- physics helpers
  private resolve(c: THREE.Vector3, r: number, out: THREE.Vector3): boolean {
    const boxes = this.map!.colliders
    out.set(0, 0, 0)
    let hit = false
    const pos = this.tmp2.copy(c)
    for (let i = 0; i < boxes.length; i++) {
      const b = boxes[i]
      const mn = b.min
      const mx = b.max
      if (pos.x + r < mn.x || pos.x - r > mx.x || pos.y + r < mn.y || pos.y - r > mx.y || pos.z + r < mn.z || pos.z - r > mx.z) continue
      const cx = Math.max(mn.x, Math.min(pos.x, mx.x))
      const cy = Math.max(mn.y, Math.min(pos.y, mx.y))
      const cz = Math.max(mn.z, Math.min(pos.z, mx.z))
      const dx = pos.x - cx
      const dy = pos.y - cy
      const dz = pos.z - cz
      const l2 = dx * dx + dy * dy + dz * dz
      if (l2 >= r * r) continue
      let px = 0
      let py = 0
      let pz = 0
      if (l2 > 1e-10) {
        const l = Math.sqrt(l2)
        const k = (r - l) / l
        px = dx * k
        py = dy * k
        pz = dz * k
      } else {
        // centre inside the box: escape along the shallowest axis
        const opts: [number, number, number, number][] = [
          [pos.x - mn.x + r, -1, 0, 0],
          [mx.x - pos.x + r, 1, 0, 0],
          [pos.y - mn.y + r, 0, -1, 0],
          [mx.y - pos.y + r, 0, 1, 0],
          [pos.z - mn.z + r, 0, 0, -1],
          [mx.z - pos.z + r, 0, 0, 1],
        ]
        opts.sort((a, b2) => a[0] - b2[0])
        px = opts[0][1] * opts[0][0]
        py = opts[0][2] * opts[0][0]
        pz = opts[0][3] * opts[0][0]
      }
      pos.x += px
      pos.y += py
      pos.z += pz
      out.x += px
      out.y += py
      out.z += pz
      hit = true
    }
    return hit
  }

  // ---------------------------------------------------------------- main loop
  private tick() {
    const dt = Math.min(0.05, this.clock.getDelta())
    this.showcaseT += dt
    if (!this.map || this.phase === 'menu') {
      this.tickMenu(dt)
      return
    }
    this.time += dt
    this.updatePlayer(dt)
    this.updateAgents(dt)
    this.updateObjects(dt)
    this.gore.update(dt)
    this.map.update(dt, this.time)
    this.updateOverlay(dt)
    this.hudAcc += dt
    if (this.hudAcc > 0.2) {
      this.hudAcc = 0
      this.emitHud()
    }
    this.renderer.render(this.scene, this.camera)
  }

  private tickMenu(dt: number) {
    if (this.renderer.xr.isPresenting) {
      this.renderer.render(this.scene, this.camera)
      return
    }
    this.showcase.forEach((s) => {
      s.t += dt
      const cyc = s.t % 9
      if (s.g.opts.monster && cyc > 6 && cyc < 6 + dt * 1.5) {
        s.g.startPose('roar', 1.8)
      }
      s.g.animate(dt, 0)
    })
    this.menuCam.position.x = 0.5 + Math.sin(this.showcaseT * 0.25) * 0.5
    this.menuCam.lookAt(0.6, 1.15, 0)
    this.renderer.render(this.menuScene, this.menuCam)
  }

  // ---------------------------------------------------------------- player
  private readVR(): { mx: number; mz: number; turn: number } {
    const session = this.renderer.xr.getSession()
    let turn = 0
    const mx = 0
    const mz = 0
    let gripCount = 0
    this.vrTrig = [false, false]
    if (session) {
      for (const src of session.inputSources) {
        const gp = src.gamepad
        if (!gp) continue
        const i = src.handedness === 'left' ? 0 : 1
        if (gp.buttons[0]?.pressed) this.vrTrig[i] = true
        if (gp.buttons[1]?.pressed) gripCount++
        if (src.handedness === 'right') {
          const ax = gp.axes[2] ?? 0
          turn = Math.abs(ax) > 0.7 ? Math.sign(ax) : 0
        }
        if (gp.buttons[4]?.pressed && this.phase === 'playing') this.jumpReq = true
      }
    }
    this.gripHeld = gripCount >= 2 ? this.gripHeld + 1 : 0
    return { mx, mz, turn }
  }

  private updatePlayer(dt: number) {
    const rig = this.rig
    const cam = this.camera
    const map = this.map!
    const playing = this.phase === 'playing'

    // ---- gather local head / hand positions
    let wantMove = false
    if (this.isVR) {
      const inp = this.readVR()
      if (inp.turn !== 0 && !this.snapLatch) {
        this.snapLatch = true
        const old = cam.position.clone().applyQuaternion(rig.quaternion)
        rig.rotation.y -= inp.turn * (Math.PI / 6)
        rig.updateMatrix()
        const neu = cam.position.clone().applyQuaternion(rig.quaternion)
        rig.position.add(old.sub(neu))
        this.skipMove = true
      }
      if (inp.turn === 0) this.snapLatch = false
      this.headRel.copy(cam.position).applyQuaternion(rig.quaternion)
      for (let i = 0; i < 2; i++) {
        const gr = this.grips.find((g) => g.userData.hand === (i === 0 ? 'left' : 'right')) ?? this.grips[i]
        this.handRel[i].copy(gr.position).applyQuaternion(rig.quaternion)
      }
      if (this.vrTrig[0] || this.vrTrig[1]) {
        if (!this.trigPrev[0] && !this.trigPrev[1]) this.senseReq = true
      }
      this.trigPrev = [...this.vrTrig]
      if (this.phase !== 'playing') {
        this.endT += dt
        if (this.endT > 2 && (this.vrTrig[0] || this.vrTrig[1])) this.restart()
        if (this.gripHeld > 90) this.exitToMenu()
      }
    } else {
      // look
      const ls = 1.9 * dt
      if (this.keys.has('ArrowLeft')) this.yaw += ls
      if (this.keys.has('ArrowRight')) this.yaw -= ls
      if (this.keys.has('ArrowUp')) this.pitch = Math.min(1.45, this.pitch + ls)
      if (this.keys.has('ArrowDown')) this.pitch = Math.max(-1.45, this.pitch - ls)
      cam.rotation.set(this.pitch, this.yaw, this.deathRoll, 'YXZ')
      cam.position.set(0, EYE, 0)
      this.headRel.set(0, EYE, 0)
      const fw = (this.keys.has('KeyW') ? 1 : 0) - (this.keys.has('KeyS') ? 1 : 0)
      const sd = (this.keys.has('KeyD') ? 1 : 0) - (this.keys.has('KeyA') ? 1 : 0)
      const forward = this.tmp.set(-Math.sin(this.yaw), 0, -Math.cos(this.yaw))
      const right = this.tmp2.set(Math.cos(this.yaw), 0, -Math.sin(this.yaw))
      const want = new THREE.Vector3().addScaledVector(forward, fw).addScaledVector(right, sd)
      const moving = want.lengthSq() > 0.01 && !this.frozen && playing
      if (moving) {
        want.normalize()
        this.curDir.lerp(want, Math.min(1, dt * 9)).normalize()
        wantMove = true
      }
      const sprint = this.keys.has('ShiftLeft') || this.keys.has('ShiftRight')
      const rate = sprint ? 2.7 : 1.85
      if (moving) this.cyc += dt * rate
      else {
        // settle to a resting stance (both hands planted)
        const rem = this.cyc % 0.5
        if (rem > 0.001) this.cyc = Math.min(this.cyc + dt * 2.2, this.cyc - rem + 0.5)
      }
      const dir = this.curDir
      const lat = new THREE.Vector3(-dir.z, 0, dir.x)
      for (let i = 0; i < 2; i++) {
        const p = (this.cyc + i * 0.5) % 1
        this.swinging[i] = p > 0.505
        let f: number
        let y: number
        if (p < 0.5) {
          f = 0.6 - (p / 0.5) * 1.05
          y = -0.04
        } else {
          const q = (p - 0.5) / 0.5
          f = -0.45 + q * 1.05
          y = -0.04 + Math.sin(q * Math.PI) * 0.5
        }
        const side = i === 0 ? -0.34 : 0.34
        this.handRel[i].set(dir.x * f + lat.x * side, y, dir.z * f + lat.z * side)
      }
      // attack swipe pulls the right hand forward visually
      if (this.attackAnim > 0) {
        this.attackAnim -= dt
        const k = 1 - this.attackAnim / 0.3
        const fwd = new THREE.Vector3(-Math.sin(this.yaw), 0, -Math.cos(this.yaw))
        this.handRel[1].set(fwd.x * (0.3 + Math.sin(k * Math.PI) * 1.0) + lat.x * 0.3, 0.9 - k * 0.5, fwd.z * (0.3 + Math.sin(k * Math.PI) * 1.0) + lat.z * 0.3)
      }
      // death roll
      if (this.frozen) this.deathRoll = Math.min(1.2, this.deathRoll + dt * 1.5)
    }
    void wantMove

    // ---- jump (desktop & VR A button)
    if (this.jumpReq) {
      this.jumpReq = false
      if (!this.frozen && playing && this.wasTouching) {
        const d = this.curDir
        const sp = (this.keys.has('ShiftLeft') ? 4.2 : 2.8) * (this.isVR ? 0.2 : 1)
        this.vel.set(d.x * sp * (wantMove ? 1 : 0), 5.4 * (this.isVR ? 0.9 : 1), d.z * sp * (wantMove ? 1 : 0))
        this.noContactT = 0.22
        this.wasTouching = false
        this.velHist = []
        this.audio.thump(0.4, 1.4)
      }
    }
    this.noContactT -= dt

    // ---- hand contacts (gorilla tag locomotion)
    if (this.frozen) {
      this.vel.multiplyScalar(0.9)
    }
    const move = new THREE.Vector3()
    let nTouch = 0
    const prevTouch = [this.touching[0], this.touching[1]]
    for (let i = 0; i < 2; i++) {
      this.tmp.copy(rig.position).add(this.handRel[i])
      const hit = this.resolve(this.tmp, HAND_R, this.push)
      this.touching[i] = hit && this.noContactT <= 0 && !this.frozen && (this.isVR || !this.swinging[i])
      if (this.touching[i]) {
        if (!this.skipMove) move.add(this.tmp.copy(this.lastHandRel[i]).sub(this.handRel[i]))
        nTouch++
        if (!prevTouch[i]) {
          const sp = Math.min(1, this.handSpeed[i] / 4)
          if (sp > 0.12) this.audio.thump(0.1 + sp * 0.5, this.map!.kind === 'ship' ? 1.3 : 1)
        }
      }
      this.lastHandRel[i].copy(this.handRel[i])
    }
    if (nTouch > 0) {
      move.divideScalar(nTouch).multiplyScalar(this.speedMult)
      move.y *= 1.0
      const ml = move.length()
      if (ml > 0.6) move.multiplyScalar(0.6 / ml)
      rig.position.add(move)
      this.velHist.push(move.clone().divideScalar(Math.max(dt, 0.001)))
      if (this.velHist.length > 6) this.velHist.shift()
      this.vel.set(0, 0, 0)
      this.wasTouching = true
    } else {
      if (this.wasTouching && this.velHist.length) {
        const avg = new THREE.Vector3()
        this.velHist.forEach((v) => avg.add(v))
        avg.divideScalar(this.velHist.length)
        const jm = this.isVR ? 1.15 : 1.0
        avg.multiplyScalar(jm)
        const max = this.cfg?.mode === 'monster' ? 11 : 8.5
        if (avg.length() > max) avg.setLength(max)
        this.vel.copy(avg)
        this.velHist = []
      }
      this.wasTouching = false
      if (!(this.frozen && this.isVR)) {
        this.vel.y -= GRAV * dt
        this.vel.multiplyScalar(1 - 0.12 * dt)
        rig.position.addScaledVector(this.vel, dt)
      }
    }
    this.skipMove = false

    // ---- head/body collision
    for (let it = 0; it < 3; it++) {
      this.tmp.copy(rig.position).add(this.headRel)
      if (this.resolve(this.tmp, HEAD_R, this.push)) {
        rig.position.add(this.push)
        const n = this.push.clone().normalize()
        const vn = this.vel.dot(n)
        if (vn < 0) this.vel.addScaledVector(n, -vn)
      }
    }
    // desktop low body sphere so waist-high furniture blocks you
    if (!this.isVR) {
      this.tmp.copy(rig.position).add(this.tmp2.set(0, 0.7, 0))
      if (this.resolve(this.tmp, 0.3, this.push)) {
        this.push.y = 0
        rig.position.add(this.push)
      }
    }
    if (rig.position.y < -4) {
      rig.position.set(map.playerSpawn.x, 0.1, map.playerSpawn.z)
      this.vel.set(0, 0, 0)
    }

    // ---- final visual positions
    this.headW.copy(rig.position).add(this.headRel)
    this.headLight.position.copy(this.headW)
    for (let i = 0; i < 2; i++) {
      this.prevHandVis[i].copy(this.handVis[i])
      this.tmp.copy(rig.position).add(this.handRel[i])
      this.resolve(this.tmp, HAND_R, this.push)
      this.handVis[i].copy(this.tmp).add(this.push)
      this.handSpeed[i] = this.handVis[i].distanceTo(this.prevHandVis[i]) / Math.max(dt, 0.001)
      if (this.handSpeed[i] > 40) this.handSpeed[i] = 0
    }
    // rig speed (noise)
    const hs = move.length() / Math.max(dt, 0.001)
    const speedNow = nTouch > 0 ? hs : Math.hypot(this.vel.x, this.vel.z)
    this.rigSpeed += (speedNow - this.rigSpeed) * Math.min(1, dt * 6)

    // ---- avatar arms
    cam.updateMatrixWorld(true)
    const fwd = this.tmp.set(0, 0, -1).applyQuaternion(cam.getWorldQuaternion(new THREE.Quaternion()))
    fwd.y = 0
    if (fwd.lengthSq() < 0.001) fwd.set(0, 0, -1)
    fwd.normalize()
    const rightV = new THREE.Vector3(0, 1, 0).cross(fwd).negate() // fwd x up = right
    const shL = this.headW.clone().addScaledVector(rightV, -0.24).addScaledVector(fwd, -0.08)
    shL.y -= 0.3
    const shR = this.headW.clone().addScaledVector(rightV, 0.24).addScaledVector(fwd, -0.08)
    shR.y -= 0.3
    const poleL = rightV.clone().multiplyScalar(-1).add(new THREE.Vector3(0, -0.2, -0.0)).addScaledVector(fwd, -0.6)
    const poleR = rightV.clone().add(new THREE.Vector3(0, -0.2, 0)).addScaledVector(fwd, -0.6)
    this.armL?.update(shL, this.handVis[0], poleL)
    this.armR?.update(shR, this.handVis[1], poleR)

    // ---- actions
    if (playing) this.playerActions(dt)
    this.attackReq = false
    this.senseReq = false
  }

  private playerActions(dt: number) {
    if (this.cfg!.mode !== 'monster') return
    // sense roar
    this.senseCd = Math.max(0, this.senseCd - dt)
    this.senseT = Math.max(0, this.senseT - dt)
    if (this.senseReq && this.senseCd <= 0) {
      this.senseCd = 14
      this.senseT = 5
      this.audio.roar(0.8)
      this.flash = Math.max(this.flash, 0.15)
      this.setMessage('ROAR! Survivors revealed...', 3)
    }
    this.agents.forEach((a) => {
      if (a.aura) a.aura.visible = a.alive && this.senseT > 0
      if (a.tag) (a.tag.material as THREE.SpriteMaterial).depthTest = !(this.senseT > 0)
    })
    // attack lunge (desktop)
    if (this.attackReq && !this.isVR) {
      this.attackAnim = 0.3
      this.audio.growl(0.3, 1.4)
      const fwd = this.tmp.set(-Math.sin(this.yaw), 0, -Math.cos(this.yaw))
      for (const a of this.agents) {
        if (!a.alive || a.kind !== 'bot') continue
        const dx = a.x - this.headW.x
        const dz = a.z - this.headW.z
        const d = Math.hypot(dx, dz)
        if (d < 3.0 && (dx * fwd.x + dz * fwd.z) / (d || 1) > 0.55 && Math.abs(this.headW.y - 1.0) < 2) this.killBot(a, new THREE.Vector3(dx, 0.2, dz).normalize())
      }
    }
    // touch kill
    for (const a of this.agents) {
      if (!a.alive || a.kind !== 'bot') continue
      const cy = 1.0
      const dh = Math.hypot(a.x - this.headW.x, cy - this.headW.y, a.z - this.headW.z)
      let hit = dh < 1.05
      for (let i = 0; i < 2 && !hit; i++) {
        const h = this.handVis[i]
        if (Math.hypot(a.x - h.x, cy - h.y, a.z - h.z) < 0.95 && (this.isVR || this.handSpeed[i] > 0.2)) hit = true
      }
      if (hit) this.killBot(a, new THREE.Vector3(a.x - this.headW.x, 0.3, a.z - this.headW.z).normalize())
    }
  }

  private killBot(a: Agent, dir: THREE.Vector3, byMonster = false) {
    if (!a.alive) return
    a.alive = false
    a.g.root.updateMatrixWorld(true)
    this.scene.remove(a.g.root)
    this.gore.explode(a.g, dir)
    this.audio.splat()
    this.audio.crunch()
    if (this.cfg!.gore) this.flash = Math.max(this.flash, byMonster ? 0 : 0.55)
    if (byMonster) {
      this.addFeed(`${a.name} was torn apart`)
    } else {
      this.kills++
      this.addFeed(`You devoured ${a.name}`)
      const left = this.agents.filter((x) => x.kind === 'bot' && x.alive).length
      this.setMessage(left > 0 ? `${a.name} eliminated! ${left} left.` : 'All survivors eliminated!', 3)
      if (left === 0) this.endGame(true, 'FEAST COMPLETE', `You hunted down all ${this.botsTotal} survivors in ${Math.floor(this.time)}s.`)
    }
  }

  private endGame(win: boolean, title: string, sub: string) {
    if (this.phase !== 'playing') return
    this.phase = win ? 'won' : 'lost'
    this.title = title
    this.subtitle = sub
    this.endT = 0
    this.frozen = !win ? this.frozen : false
    if (win) this.audio.win()
    else this.audio.lose()
    if (document.pointerLockElement && !win) {
      /* keep lock so R restarts easily */
    }
    this.drawEndPanel()
    this.endPanel.mesh.visible = this.isVR
    this.emitHud()
  }

  // ---------------------------------------------------------------- agents
  private moveAgent(a: Agent, speed: number, dt: number) {
    let moved = 0
    while (a.path.length && Math.hypot(a.path[0].x - a.x, a.path[0].z - a.z) < 0.3) a.path.shift()
    if (a.path.length) {
      const wp = a.path[0]
      const dx = wp.x - a.x
      const dz = wp.z - a.z
      const d = Math.hypot(dx, dz)
      a.yaw = lerpAngle(a.yaw, Math.atan2(dx, dz), 1 - Math.exp(-9 * dt))
      const step = Math.min(d, speed * dt)
      a.x += (dx / d) * step
      a.z += (dz / d) * step
      moved = step / dt
    }
    a.curSpeed += (moved - a.curSpeed) * Math.min(1, dt * 8)
    a.g.root.position.set(a.x, 0, a.z)
    a.g.root.rotation.y = a.yaw
    a.g.animate(dt, a.curSpeed)
    return moved
  }

  private updateAgents(dt: number) {
    const cfg = this.cfg!
    const d = DIFF[cfg.difficulty]
    const monsterMode = cfg.mode === 'monster'
    this.introT = Math.max(0, this.introT - dt)
    let danger = 0
    for (const a of this.agents) {
      if (!a.alive) continue
      a.hitCd = Math.max(0, a.hitCd - dt)
      if (a.kind === 'bot') this.botThink(a, dt, d, monsterMode)
      else {
        this.monsterThink(a, dt, d)
        const dist = Math.hypot(a.x - this.headW.x, a.z - this.headW.z)
        danger = Math.max(danger, 1 - Math.min(1, dist / 22))
      }
    }
    this.danger += (danger - this.danger) * Math.min(1, dt * 3)
    // heartbeat
    if (!monsterMode && this.phase === 'playing' && this.danger > 0.3) {
      this.heartAcc -= dt
      if (this.heartAcc <= 0) {
        this.heartAcc = 1.2 - this.danger * 0.75
        this.audio.heartbeat(0.25 + this.danger * 0.6)
      }
    }
    // survive-mode bots reaching the exit
    if (!monsterMode && this.map && this.cellsGot >= this.cellObjs.length) {
      for (const a of this.agents) {
        if (a.kind === 'bot' && a.alive && Math.hypot(a.x - this.map.exit.x, a.z - this.map.exit.z) < 2.4) {
          a.alive = false
          this.scene.remove(a.g.root)
          this.escaped++
          this.addFeed(`${a.name} escaped!`)
        }
      }
    }
    // timer / end conditions (monster mode)
    if (monsterMode && this.phase === 'playing' && this.time > MONSTER_TIME) {
      const left = this.agents.filter((x) => x.kind === 'bot' && x.alive).length
      this.endGame(false, 'TIME IS UP', `${left} survivor${left === 1 ? '' : 's'} escaped your hunger.`)
    }
  }

  private botThink(a: Agent, dt: number, d: (typeof DIFF)['normal'], monsterMode: boolean) {
    const map = this.map!
    const nav = map.nav
    let tx: number
    let tz: number
    if (monsterMode) {
      tx = this.headW.x
      tz = this.headW.z
    } else {
      tx = this.monster!.x
      tz = this.monster!.z
    }
    const dist = Math.hypot(tx - a.x, tz - a.z)
    const sees = dist < 16 && nav.hasLOS(a.x, a.z, tx, tz)
    const alarmed = (dist < 14 && sees) || dist < 5
    a.repath -= dt
    if (alarmed && this.phase === 'playing') {
      if (a.state !== 'flee') {
        a.state = 'flee'
        a.repath = 0
        if (Math.random() < 0.5) this.audio.screech()
      }
      if (a.repath <= 0) {
        a.repath = 0.7
        let best: P2 | null = null
        let bs = -Infinity
        for (let k = 0; k < 12; k++) {
          const c = this.free[Math.floor(Math.random() * this.free.length)]
          const s = Math.hypot(c.x - tx, c.z - tz) - 0.45 * Math.hypot(c.x - a.x, c.z - a.z) + (nav.hasLOS(c.x, c.z, tx, tz) ? -8 : 6)
          if (s > bs) {
            bs = s
            best = c
          }
        }
        if (best) a.path = nav.findPath(a.x, a.z, best.x, best.z)
      }
      this.moveAgent(a, d.flee, dt)
    } else {
      if (a.state === 'flee') {
        a.state = 'idle'
        a.stateT = 0.5
      }
      a.stateT -= dt
      if (a.state === 'idle') {
        a.curSpeed *= 0.9
        a.g.animate(dt, 0)
        if (a.stateT <= 0) {
          a.state = 'wander'
          const exitOpen = !monsterMode && this.cellsGot >= this.cellObjs.length
          const goal = exitOpen && Math.random() < 0.8 ? map.exit : this.free[Math.floor(Math.random() * this.free.length)]
          a.path = nav.findPath(a.x, a.z, goal.x, goal.z)
        }
      } else {
        this.moveAgent(a, 2.7, dt)
        if (!a.path.length) {
          a.state = 'idle'
          a.stateT = 1 + Math.random() * 3
        }
      }
    }
  }

  private monsterThink(a: Agent, dt: number, d: (typeof DIFF)['normal']) {
    const map = this.map!
    const nav = map.nav
    if (this.phase !== 'playing') {
      // gloat
      a.g.animate(dt, 0)
      return
    }
    // intro: monster sleeps / roars
    if (a.state === 'intro') {
      a.g.animate(dt, 0)
      if (this.introT <= 0) {
        a.state = 'patrol'
        a.g.startPose('roar', 2.2)
        this.audio.roar(0.9)
        this.setMessage('The monster has awoken. RUN.', 4)
        this.flash = Math.max(this.flash, 0.2)
      }
      return
    }
    if (a.stateT > 0 && a.state !== 'patrol' && a.state !== 'chase' && a.state !== 'search') {
      a.stateT -= dt
    }
    if (a.hitCd > 0) {
      // eating
      a.g.animate(dt, 0)
      return
    }
    const cellMult = 1 + this.cellsGot * 0.07
    // targets
    a.repath -= dt
    this.growlAcc -= dt
    if (this.growlAcc <= 0) {
      this.growlAcc = 9 + Math.random() * 8
      const dist = Math.hypot(a.x - this.headW.x, a.z - this.headW.z)
      this.audio.growl(Math.max(0.1, 0.8 - dist / 40), 0.9 + Math.random() * 0.2)
    }
    if (a.repath <= 0) {
      a.repath = 0.3
      // pick victim
      let best: { x: number; z: number; w: number; isPlayer: boolean; bot?: Agent } | null = null
      let bw = Infinity
      const pd = Math.hypot(this.headW.x - a.x, this.headW.z - a.z)
      const hearing = 5 + this.rigSpeed * 1.8 * d.hear
      if (!this.frozen && ((pd < 32 && nav.hasLOS(a.x, a.z, this.headW.x, this.headW.z)) || pd < hearing)) {
        bw = pd * 0.75
        best = { x: this.headW.x, z: this.headW.z, w: bw, isPlayer: true }
      }
      for (const b of this.agents) {
        if (b.kind !== 'bot' || !b.alive) continue
        const bd = Math.hypot(b.x - a.x, b.z - a.z)
        if (bd < 24 && nav.hasLOS(a.x, a.z, b.x, b.z) && bd < bw) {
          bw = bd
          best = { x: b.x, z: b.z, w: bd, isPlayer: false, bot: b }
        }
      }
      if (best) {
        if (a.state !== 'chase' && best.isPlayer) {
          this.audio.growl(0.9, 1.05)
          this.audio.screech()
        }
        a.state = 'chase'
        a.lastKnown = { x: best.x, z: best.z }
        a.stateT = 0
        a.path = nav.findPath(a.x, a.z, best.x, best.z)
      } else if (a.state === 'chase') {
        a.state = 'search'
        a.stateT = 5
        if (a.lastKnown) a.path = nav.findPath(a.x, a.z, a.lastKnown.x, a.lastKnown.z)
      } else if (a.state === 'search') {
        a.stateT -= 0.3
        if (!a.path.length) {
          const c = this.free[Math.floor(Math.random() * this.free.length)]
          a.path = nav.findPath(a.x, a.z, c.x, c.z)
        }
        if (a.stateT <= 0) a.state = 'patrol'
      } else if (!a.path.length) {
        // director: sometimes patrol toward the player
        const target = Math.random() < 0.65 ? { x: this.headW.x, z: this.headW.z } : this.free[Math.floor(Math.random() * this.free.length)]
        a.path = nav.findPath(a.x, a.z, target.x, target.z)
        a.state = 'patrol'
      }
    }
    const speed = a.state === 'chase' ? d.chase * cellMult : a.state === 'search' ? d.patrol * 1.3 * cellMult : d.patrol * cellMult
    const moved = this.moveAgent(a, speed, dt)
    // footsteps
    a.stepAcc += moved * dt
    if (a.stepAcc > 1.7) {
      a.stepAcc = 0
      const dist = Math.hypot(a.x - this.headW.x, a.z - this.headW.z)
      this.audio.thump(Math.max(0.05, 0.9 - dist / 30), 0.55)
    }
    // attacks
    for (const b of this.agents) {
      if (b.kind !== 'bot' || !b.alive) continue
      if (Math.hypot(b.x - a.x, b.z - a.z) < 1.9) {
        a.g.startPose('attack', 0.45)
        a.hitCd = 1.1
        this.killBot(b, new THREE.Vector3(b.x - a.x, 0.3, b.z - a.z).normalize(), true)
        return
      }
    }
    if (!this.frozen) {
      const h = Math.hypot(a.x - this.headW.x, a.z - this.headW.z)
      if (h < 1.9 && this.headW.y < 3.4) {
        a.g.startPose('attack', 0.45)
        a.hitCd = 2
        this.killPlayer(a)
      }
    }
  }

  private killPlayer(a: Agent) {
    this.frozen = true
    this.vel.set(0, 0, 0)
    this.flash = 1
    this.audio.splat()
    this.audio.growl(1, 0.9)
    this.gore.burst(this.headW, 140, 5, 1, new THREE.Vector3(a.x - this.headW.x, 0, a.z - this.headW.z).normalize().negate())
    for (let i = 0; i < 10; i++) this.gore.decal(this.headW.x + (Math.random() - 0.5) * 2, this.headW.z + (Math.random() - 0.5) * 2, 0.6 + Math.random())
    this.endGame(false, 'YOU WERE TORN APART', `The monster got you after ${Math.floor(this.time)}s. ${this.cellsGot}/${this.cellObjs.length} cells collected.`)
  }

  // ---------------------------------------------------------------- objects
  private updateObjects(dt: number) {
    const cfg = this.cfg!
    const map = this.map!
    this.messageT -= dt
    if (this.messageT <= 0) this.message = ''
    this.feed = this.feed.filter((f) => this.time - f.t < 9)
    if (cfg.mode !== 'survive') return
    for (const c of this.cellObjs) {
      if (c.taken) continue
      c.g.rotation.y += dt * 1.6
      c.g.position.y = 1.0 + Math.sin(this.time * 2 + c.phase) * 0.12
      if (this.phase !== 'playing') continue
      let near = Math.hypot(c.p.x - this.headW.x, c.g.position.y - this.headW.y, c.p.z - this.headW.z) < 1.5
      for (let i = 0; i < 2 && !near; i++) {
        const h = this.handVis[i]
        near = Math.hypot(c.p.x - h.x, c.g.position.y - h.y, c.p.z - h.z) < 1.1
      }
      if (near) {
        c.taken = true
        c.g.visible = false
        this.cellsGot++
        this.audio.pickup()
        const left = this.cellObjs.length - this.cellsGot
        if (left === 0) {
          map.setExitOpen(true)
          this.audio.alarm()
          this.setMessage('ALL CELLS COLLECTED — THE EXIT IS OPEN! RUN!', 6)
          if (this.monster) {
            this.monster.state = 'chase'
            this.monster.lastKnown = { x: this.headW.x, z: this.headW.z }
            this.monster.path = map.nav.findPath(this.monster.x, this.monster.z, this.headW.x, this.headW.z)
            this.audio.roar(0.9)
          }
        } else {
          this.setMessage(`Power cell collected (${this.cellsGot}/${this.cellObjs.length}). The monster grows angrier...`, 4)
          if (this.monster && this.monster.state !== 'chase') {
            this.monster.state = 'search'
            this.monster.stateT = 6
            this.monster.lastKnown = { x: c.p.x, z: c.p.z }
            this.monster.path = map.nav.findPath(this.monster.x, this.monster.z, this.headW.x, this.headW.z)
          }
        }
      }
    }
    if (this.phase === 'playing' && this.cellsGot >= this.cellObjs.length && Math.hypot(map.exit.x - this.headW.x, map.exit.z - this.headW.z) < 2.3 && this.headW.y < 4) {
      const alive = this.agents.filter((x) => x.kind === 'bot' && x.alive).length
      this.endGame(true, 'YOU ESCAPED!', `Out in ${Math.floor(this.time)}s with ${alive + this.escaped} of ${this.botsTotal} fellow gorillas surviving.`)
    }
  }

  // ---------------------------------------------------------------- overlay / panels / hud
  private updateOverlay(dt: number) {
    this.flash = Math.max(0, this.flash - dt * (this.phase === 'lost' ? 0.15 : 0.7))
    const f = this.phase === 'lost' ? Math.max(this.flash, 0.45) : this.flash
    this.flashEl.style.opacity = this.isVR ? '0' : String(f)
    ;(this.flashQuad.material as THREE.MeshBasicMaterial).opacity = this.isVR ? f * 0.85 : 0
    if (this.isVR) {
      this.wristAcc += dt
      if (this.wristAcc > 0.25) {
        this.wristAcc = 0
        this.drawWrist()
      }
    }
  }

  private drawWrist() {
    const p = this.wrist
    const g = p.ctx
    g.clearRect(0, 0, p.w, p.h)
    g.fillStyle = 'rgba(8,10,14,0.88)'
    g.fillRect(0, 0, p.w, p.h)
    g.strokeStyle = this.cfg?.mode === 'monster' ? '#ff4040' : '#4af0d6'
    g.lineWidth = 8
    g.strokeRect(4, 4, p.w - 8, p.h - 8)
    g.fillStyle = '#fff'
    g.font = 'bold 40px sans-serif'
    const lines: string[] = []
    if (this.cfg?.mode === 'monster') {
      lines.push('MONSTER MODE')
      lines.push(`Time  ${Math.max(0, Math.ceil(MONSTER_TIME - this.time))}s`)
      lines.push(`Prey  ${this.agents.filter((a) => a.kind === 'bot' && a.alive).length}/${this.botsTotal}`)
      lines.push(this.senseCd > 0 ? `Roar  ${Math.ceil(this.senseCd)}s` : 'Roar READY (trigger)')
    } else {
      lines.push('SURVIVE')
      lines.push(`Cells ${this.cellsGot}/${this.cellObjs.length}`)
      lines.push(this.cellsGot >= this.cellObjs.length ? 'EXIT OPEN!' : 'Find the cells')
      lines.push(`Danger ${'|'.repeat(Math.round(this.danger * 10))}`)
    }
    lines.forEach((l, i) => g.fillText(l, 28, 70 + i * 66))
    p.tex.needsUpdate = true
  }

  private drawEndPanel() {
    const p = this.endPanel
    const g = p.ctx
    g.clearRect(0, 0, p.w, p.h)
    const win = this.phase === 'won'
    g.fillStyle = 'rgba(6,6,10,0.92)'
    g.fillRect(0, 0, p.w, p.h)
    g.strokeStyle = win ? '#4af070' : '#ff3030'
    g.lineWidth = 10
    g.strokeRect(5, 5, p.w - 10, p.h - 10)
    g.textAlign = 'center'
    g.fillStyle = win ? '#6dff90' : '#ff4a4a'
    g.font = 'bold 64px sans-serif'
    g.fillText(this.title, p.w / 2, 140)
    g.fillStyle = '#ddd'
    g.font = '30px sans-serif'
    const words = this.subtitle.split(' ')
    let line = ''
    let y = 230
    for (const w of words) {
      if (g.measureText(line + w).width > p.w - 120) {
        g.fillText(line, p.w / 2, y)
        line = ''
        y += 42
      }
      line += w + ' '
    }
    g.fillText(line, p.w / 2, y)
    g.fillStyle = '#fff'
    g.font = 'bold 32px sans-serif'
    g.fillText('Press a TRIGGER to play again', p.w / 2, p.h - 100)
    g.fillStyle = '#999'
    g.font = '26px sans-serif'
    g.fillText('Hold both GRIPS for 1.5s to return to menu', p.w / 2, p.h - 50)
    p.tex.needsUpdate = true
  }

  emitHud() {
    const botsAlive = this.agents.filter((a) => a.kind === 'bot' && a.alive).length
    this.onHud({
      phase: this.phase,
      mode: this.cfg?.mode ?? 'survive',
      map: this.cfg?.map ?? 'backrooms',
      time: this.time,
      timeLeft: Math.max(0, MONSTER_TIME - this.time),
      cells: this.cellsGot,
      cellsTotal: this.cellObjs.length,
      exitOpen: this.cellObjs.length > 0 && this.cellsGot >= this.cellObjs.length,
      kills: this.kills,
      botsAlive,
      botsTotal: this.botsTotal,
      botsEscaped: this.escaped,
      message: this.message,
      senseCd: this.senseCd,
      danger: this.danger,
      vr: this.isVR,
      locked: this.locked,
      feed: this.feed.map((f) => f.text),
      title: this.title,
      subtitle: this.subtitle,
      intro: this.introT,
    })
  }
}
