import * as THREE from 'three'
import { LAYOUTS } from './layouts'
import { NavGrid, type P2 } from './nav'
import { getTexture, makePaintingTexture, tiledBox, type TexKind } from './textures'
import { makeNameTag, type MonsterVariant } from './gorilla'

export type MapKind = 'backrooms' | 'mansion' | 'ship'

export interface GameMap {
  kind: MapKind
  name: string
  group: THREE.Group
  nav: NavGrid
  colliders: THREE.Box3[]
  wallH: number
  playerSpawn: P2
  monsterSpawn: P2
  exit: P2
  cells: P2[]
  botSpawns: P2[]
  variant: MonsterVariant
  fogColor: number
  fogDensity: number
  headLight: { color: number; intensity: number; distance: number }
  setExitOpen: (open: boolean) => void
  exitGroup: THREE.Group
  update: (dt: number, t: number) => void
  dispose: () => void
}

const CELL = 4

function hash(x: number, y: number, k = 0) {
  let h = (x * 73856093) ^ (y * 19349663) ^ (k * 83492791)
  h = (h ^ (h >>> 13)) * 1274126177
  return (h >>> 0) % 1000
}

export function buildMap(kind: MapKind): GameMap {
  const rows = LAYOUTS[kind]
  const nav = new NavGrid(rows, CELL)
  const W = nav.W
  const H = nav.H
  const group = new THREE.Group()
  const colliders: THREE.Box3[] = []
  const updaters: ((dt: number, t: number) => void)[] = []

  const cfg = {
    backrooms: { wallH: 3.2, wall: 'backWall', floor: 'backFloor', ceil: 'backCeil', tile: 3, name: 'The Backrooms', variant: 'entity' as MonsterVariant, fog: 0x8a7a38, fogD: 0.03, head: { color: 0xfff3c0, intensity: 6, distance: 8 } },
    mansion: { wallH: 4.4, wall: 'manWall', floor: 'manFloor', ceil: 'manCeil', tile: 3, name: 'Haunted Mansion', variant: 'possessed' as MonsterVariant, fog: 0x08060c, fogD: 0.055, head: { color: 0xffb060, intensity: 38, distance: 13 } },
    ship: { wallH: 3.8, wall: 'shipWall', floor: 'shipFloor', ceil: 'shipCeil', tile: 3.6, name: 'Alien Mothership', variant: 'xeno' as MonsterVariant, fog: 0x04090d, fogD: 0.035, head: { color: 0x9afff0, intensity: 22, distance: 11 } },
  }[kind]
  const wallH = cfg.wallH
  const mapW = W * CELL
  const mapD = H * CELL

  const mat = (k: TexKind, color = 0xffffff) => new THREE.MeshLambertMaterial({ map: getTexture(k), color })
  const wallMat = mat(cfg.wall as TexKind)
  const floorMat = mat(cfg.floor as TexKind)
  const ceilMat = mat(cfg.ceil as TexKind)
  const glow = (c: number) => new THREE.MeshBasicMaterial({ color: c })

  const addBox = (geo: THREE.BufferGeometry, m: THREE.Material, x: number, y: number, z: number, collide?: [number, number, number]) => {
    const mesh = new THREE.Mesh(geo, m)
    mesh.position.set(x, y, z)
    group.add(mesh)
    if (collide) colliders.push(new THREE.Box3(new THREE.Vector3(x - collide[0] / 2, y - collide[1] / 2, z - collide[2] / 2), new THREE.Vector3(x + collide[0] / 2, y + collide[1] / 2, z + collide[2] / 2)))
    return mesh
  }

  // floor + ceiling
  const pad = 12
  const fw = mapW + pad * 2
  const fd = mapD + pad * 2
  const tileF = kind === 'backrooms' ? 2 : 4
  addBox(tiledBox(fw, 2, fd, tileF, tileF), floorMat, mapW / 2, -1, mapD / 2, [fw, 2, fd])
  addBox(tiledBox(fw, 2, fd, kind === 'backrooms' ? 2 : 4, 4), ceilMat, mapW / 2, wallH + 1, mapD / 2, [fw, 2, fd])

  // walls (merged horizontal runs)
  for (let y = 0; y < H; y++) {
    let x = 0
    while (x < W) {
      if (!nav.isWall(x, y)) {
        x++
        continue
      }
      let x2 = x
      while (x2 + 1 < W && nav.isWall(x2 + 1, y)) x2++
      const len = (x2 - x + 1) * CELL
      addBox(tiledBox(len, wallH, CELL, cfg.tile, wallH), wallMat, x * CELL + len / 2, wallH / 2, (y + 0.5) * CELL, [len, wallH, CELL])
      x = x2 + 1
    }
  }
  // outer surrounding barrier (so nobody can leave via perimeter)
  const bw = 6
  for (const [x, z, w, d] of [
    [-bw / 2, mapD / 2, bw, mapD + bw * 2],
    [mapW + bw / 2, mapD / 2, bw, mapD + bw * 2],
    [mapW / 2, -bw / 2, mapW, bw],
    [mapW / 2, mapD + bw / 2, mapW, bw],
  ]) {
    colliders.push(new THREE.Box3(new THREE.Vector3(x - w / 2, 0, z - d / 2), new THREE.Vector3(x + w / 2, wallH, z + d / 2)))
  }

  const freeCells: { cx: number; cy: number }[] = []
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (!nav.blocked(x, y)) freeCells.push({ cx: x, cy: y })

  // iterate wall faces adjacent to floor
  const faces: { x: number; z: number; rot: number; nx: number; nz: number; cx: number; cy: number; d: number }[] = []
  for (let y = 0; y < H; y++)
    for (let x = 0; x < W; x++) {
      if (!nav.isWall(x, y)) continue
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        if (nav.blocked(x + dx, y + dy)) continue
        const c = nav.center(x, y)
        faces.push({ x: c.x + dx * (CELL / 2 + 0.03), z: c.z + dy * (CELL / 2 + 0.03), rot: Math.atan2(dx, dy), nx: dx, nz: dy, cx: x, cy: y, d: hash(x, y, dx * 3 + dy) })
      }
    }

  let ambient: THREE.Light
  const flashMats: THREE.MeshBasicMaterial[] = []
  let lightningT = 0

  if (kind === 'backrooms') {
    ambient = new THREE.HemisphereLight(0xfff0a8, 0x8a7a30, 2.7)
    group.add(ambient)
    // fluorescent panels
    const panelGeo = new THREE.BoxGeometry(1.6, 0.06, 0.7)
    const panelMat = glow(0xfffbe0)
    const panelCells = freeCells.filter((c) => (c.cx + c.cy) % 2 === 0 && hash(c.cx, c.cy, 5) % 9 !== 0)
    const inst = new THREE.InstancedMesh(panelGeo, panelMat, panelCells.length)
    const dm = new THREE.Object3D()
    panelCells.forEach((c, i) => {
      const p = nav.center(c.cx, c.cy)
      dm.position.set(p.x, wallH - 0.04, p.z)
      dm.rotation.y = hash(c.cx, c.cy, 2) % 2 ? Math.PI / 2 : 0
      dm.updateMatrix()
      inst.setMatrixAt(i, dm.matrix)
    })
    group.add(inst)
    // flickering panels
    const flickMat = glow(0xfffbe0)
    const flickCells = freeCells.filter((c) => hash(c.cx, c.cy, 5) % 9 === 0)
    flickCells.forEach((c) => {
      const p = nav.center(c.cx, c.cy)
      const m = new THREE.Mesh(panelGeo, flickMat)
      m.position.set(p.x, wallH - 0.04, p.z)
      group.add(m)
    })
    updaters.push((_dt, t) => {
      const f = Math.sin(t * 37) * Math.sin(t * 11.3) > 0.55 || Math.sin(t * 2.1) > 0.97
      flickMat.color.setHex(f ? 0x3a3520 : 0xfffbe0)
    })
    // pillars
    for (let y = 0; y < H; y++)
      for (let x = 0; x < W; x++)
        if (nav.at(x, y) === 'o') {
          const c = nav.center(x, y)
          addBox(tiledBox(1.7, wallH, 1.7, 2, wallH), mat('pillar'), c.x, wallH / 2, c.z, [1.7, wallH, 1.7])
        }
    // wall signs / stains: dark "EXIT?" scribbles skipped; add yellow warning posters
    faces.forEach((f) => {
      if (f.d % 23 !== 0) return
      const c = document.createElement('canvas')
      c.width = c.height = 64
      const g = c.getContext('2d')!
      g.fillStyle = '#e8e2c0'
      g.fillRect(0, 0, 64, 64)
      g.fillStyle = '#111'
      g.font = 'bold 12px sans-serif'
      g.textAlign = 'center'
      g.fillText(['DON\'T', 'LOOK', 'BEHIND', 'YOU'][f.d % 4], 32, 22)
      g.fillText(['STOP', 'RUN', '...', 'LEVEL 0'][f.d % 4], 32, 44)
      const t = new THREE.CanvasTexture(c)
      t.colorSpace = THREE.SRGBColorSpace
      const m = new THREE.Mesh(new THREE.PlaneGeometry(0.7, 0.7), new THREE.MeshLambertMaterial({ map: t }))
      m.position.set(f.x, 1.7, f.z)
      m.rotation.y = f.rot
      group.add(m)
    })
  } else if (kind === 'mansion') {
    const amb = new THREE.AmbientLight(0x4a4a78, 1.15)
    ambient = amb
    group.add(amb, new THREE.HemisphereLight(0x6070a0, 0x24100a, 0.9))
    const candleFlame = glow(0xffc060)
    const gold = new THREE.MeshStandardMaterial({ color: 0x8a6a22, metalness: 0.8, roughness: 0.4 })
    const wax = new THREE.MeshLambertMaterial({ color: 0xe8dfc4 })
    // chandeliers
    freeCells.forEach((c) => {
      if (hash(c.cx, c.cy, 9) % 4 !== 0) return
      const p = nav.center(c.cx, c.cy)
      const g = new THREE.Group()
      g.position.set(p.x, wallH - 1.3, p.z)
      const ring = new THREE.Mesh(new THREE.TorusGeometry(0.7, 0.05, 6, 20), gold)
      ring.rotation.x = Math.PI / 2
      g.add(ring)
      const chain = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 1.3, 5), gold)
      chain.position.y = 0.65
      g.add(chain)
      for (let i = 0; i < 6; i++) {
        const a = (i / 6) * Math.PI * 2
        const cd = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.22, 6), wax)
        cd.position.set(Math.cos(a) * 0.7, 0.12, Math.sin(a) * 0.7)
        const fl = new THREE.Mesh(new THREE.ConeGeometry(0.035, 0.1, 6), candleFlame)
        fl.position.set(Math.cos(a) * 0.7, 0.29, Math.sin(a) * 0.7)
        g.add(cd, fl)
      }
      group.add(g)
    })
    // static candle lights
    const cl1 = new THREE.PointLight(0xff9040, 30, 16, 2)
    const cl2 = new THREE.PointLight(0xff9040, 30, 16, 2)
    const cl3 = new THREE.PointLight(0x7080ff, 22, 18, 2)
    const mid = nav.center(10, 6)
    cl1.position.set(mid.x, 3.2, mid.z)
    const pc = nav.center(10, 12)
    cl2.position.set(pc.x, 3.2, pc.z)
    const tc = nav.center(4, 2)
    cl3.position.set(tc.x, 3.2, tc.z)
    group.add(cl1, cl2, cl3)
    updaters.push((dt, t) => {
      cl1.intensity = 30 + Math.sin(t * 13) * 4 + Math.sin(t * 7.3) * 3
      cl2.intensity = 30 + Math.sin(t * 11 + 2) * 4
      cl3.intensity = 22 + Math.sin(t * 5) * 3
      lightningT -= dt
      if (lightningT < -9 + Math.random() * 4 && Math.random() < 0.02) lightningT = 0.5
      const flash = lightningT > 0 ? (Math.sin(lightningT * 60) > 0 ? 1 : 0.3) * Math.min(1, lightningT * 3) : 0
      amb.intensity = 1.15 + flash * 4
      flashMats.forEach((m) => m.color.setRGB(0.06 + flash * 0.8, 0.09 + flash * 0.85, 0.18 + flash * 0.9))
    })
    // furniture
    for (let y = 0; y < H; y++)
      for (let x = 0; x < W; x++) {
        if (nav.at(x, y) !== 'o') continue
        const c = nav.center(x, y)
        const h = hash(x, y, 4) % 3
        const rot = (hash(x, y, 8) % 2) * Math.PI / 2
        const g = new THREE.Group()
        g.position.set(c.x, 0, c.z)
        g.rotation.y = rot
        const cos = Math.cos(rot)
        const sin = Math.sin(rot)
        const bx = (w: number, d: number) => (Math.abs(cos) > 0.5 ? [w, d] : [d, w])
        if (h === 0) {
          // bookshelf
          const shelf = new THREE.Mesh(tiledBox(3.2, 2.7, 0.8, 1.5, 2.7), mat('bookshelf'))
          shelf.position.y = 1.35
          g.add(shelf)
          const [cw, cd] = bx(3.2, 0.8)
          colliders.push(new THREE.Box3(new THREE.Vector3(c.x - cw / 2, 0, c.z - cd / 2), new THREE.Vector3(c.x + cw / 2, 2.7, c.z + cd / 2)))
        } else if (h === 1) {
          // table with candelabra
          const top = new THREE.Mesh(tiledBox(2.4, 0.15, 1.3, 1.2, 1.2), mat('wood'))
          top.position.y = 0.95
          g.add(top)
          for (const [lx, lz] of [[-1, -0.5], [1, -0.5], [-1, 0.5], [1, 0.5]]) {
            const leg = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.95, 0.15), mat('wood'))
            leg.position.set(lx, 0.47, lz)
            g.add(leg)
          }
          const cd = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.35, 6), wax)
          cd.position.y = 1.2
          const fl = new THREE.Mesh(new THREE.ConeGeometry(0.04, 0.12, 6), candleFlame)
          fl.position.y = 1.43
          g.add(cd, fl)
          const [cw, cd2] = bx(2.4, 1.3)
          colliders.push(new THREE.Box3(new THREE.Vector3(c.x - cw / 2, 0.85, c.z - cd2 / 2), new THREE.Vector3(c.x + cw / 2, 1.05, c.z + cd2 / 2)))
        } else {
          // coffin
          const cof = new THREE.Mesh(tiledBox(1.1, 0.8, 2.4, 1, 1), mat('wood', 0x9a8a8a))
          cof.position.y = 0.4
          const lid = new THREE.Mesh(tiledBox(1.0, 0.1, 2.3, 1, 1), mat('wood', 0xbbaaaa))
          lid.position.set(0.18, 0.85, 0.1)
          lid.rotation.y = 0.12
          g.add(cof, lid)
          const [cw, cd2] = bx(1.1, 2.4)
          colliders.push(new THREE.Box3(new THREE.Vector3(c.x - cw / 2, 0, c.z - cd2 / 2), new THREE.Vector3(c.x + cw / 2, 0.95, c.z + cd2 / 2)))
        }
        void sin
        group.add(g)
      }
    // paintings & windows
    const frameMat = new THREE.MeshLambertMaterial({ color: 0x3a2410 })
    faces.forEach((f) => {
      if (f.d % 9 === 0) {
        const t = makePaintingTexture(f.d)
        const m = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 1.5), new THREE.MeshLambertMaterial({ map: t, emissive: 0x201010 }))
        m.position.set(f.x, 2.3, f.z)
        m.rotation.y = f.rot
        group.add(m)
      } else if (f.d % 9 === 4) {
        const gm = new THREE.MeshBasicMaterial({ color: 0x0f1730 })
        flashMats.push(gm)
        const win = new THREE.Mesh(new THREE.PlaneGeometry(1.4, 2.2), gm)
        win.position.set(f.x, 2.3, f.z)
        win.rotation.y = f.rot
        const fr = new THREE.Mesh(new THREE.BoxGeometry(1.6, 2.4, 0.08), frameMat)
        fr.position.set(f.x - f.nx * 0.01, 2.3, f.z - f.nz * 0.01)
        fr.rotation.y = f.rot
        const cross = new THREE.Mesh(new THREE.BoxGeometry(0.06, 2.2, 0.1), frameMat)
        cross.position.copy(win.position).addScaledVector(new THREE.Vector3(f.nx, 0, f.nz), 0.02)
        cross.rotation.y = f.rot
        group.add(fr, win, cross)
      }
    })
    // blood stains on the floor
    freeCells.forEach((c) => {
      if (hash(c.cx, c.cy, 77) % 6 !== 0) return
      const p = nav.center(c.cx, c.cy)
      const st = new THREE.Mesh(new THREE.CircleGeometry(0.5 + (hash(c.cx, c.cy, 3) % 10) / 10, 10), new THREE.MeshLambertMaterial({ color: 0x4a0508, transparent: true, opacity: 0.85, polygonOffset: true, polygonOffsetFactor: -1 }))
      st.rotation.x = -Math.PI / 2
      st.position.set(p.x + ((hash(c.cx, c.cy, 5) % 20) - 10) / 6, 0.008, p.z + ((hash(c.cx, c.cy, 6) % 20) - 10) / 6)
      group.add(st)
    })
  } else {
    ambient = new THREE.HemisphereLight(0x7aa8c8, 0x1a2a38, 1.5)
    group.add(ambient)
    const red = new THREE.PointLight(0xff2a2a, 30, 20, 2)
    const rp = nav.center(10, 7)
    red.position.set(rp.x, 3.2, rp.z)
    const green = new THREE.PointLight(0x40ffa0, 30, 20, 2)
    const gp = nav.center(11, 12)
    green.position.set(gp.x, 3, gp.z)
    group.add(red, green)
    updaters.push((_dt, t) => {
      red.intensity = 6 + Math.max(0, Math.sin(t * 2.2)) * 40
    })
    // ceiling light strips
    const stripGeo = new THREE.BoxGeometry(2.8, 0.06, 0.22)
    const cellsStrip = freeCells.filter((c) => hash(c.cx, c.cy, 1) % 2 === 0)
    const inst = new THREE.InstancedMesh(stripGeo, glow(0x7ffcf0), cellsStrip.length)
    const dm = new THREE.Object3D()
    cellsStrip.forEach((c, i) => {
      const p = nav.center(c.cx, c.cy)
      dm.position.set(p.x, wallH - 0.04, p.z)
      dm.rotation.y = hash(c.cx, c.cy, 2) % 2 ? Math.PI / 2 : 0
      dm.updateMatrix()
      inst.setMatrixAt(i, dm.matrix)
    })
    group.add(inst)
    // pipes
    const pipeMat = new THREE.MeshStandardMaterial({ color: 0x59636e, metalness: 0.7, roughness: 0.4 })
    for (const zc of [2, 6.5, 13, 17]) {
      const p = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.16, mapW, 8), pipeMat)
      p.rotation.z = Math.PI / 2
      p.position.set(mapW / 2, wallH - 0.4, zc * CELL)
      group.add(p)
    }
    for (const xc of [4, 10.5, 17]) {
      const p = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, mapD, 8), pipeMat)
      p.rotation.x = Math.PI / 2
      p.position.set(xc * CELL, wallH - 0.7, mapD / 2)
      group.add(p)
    }
    // obstacles
    const eggMat = new THREE.MeshStandardMaterial({ map: getTexture('alienFlesh'), emissive: 0x0f5a38, emissiveIntensity: 1, roughness: 0.3 })
    for (let y = 0; y < H; y++)
      for (let x = 0; x < W; x++) {
        if (nav.at(x, y) !== 'o') continue
        const c = nav.center(x, y)
        if (hash(x, y, 4) % 2 === 0) {
          addBox(tiledBox(3, 1.6, 3, 1.5, 1.5), mat('crate'), c.x, 0.8, c.z, [3, 1.6, 3])
          addBox(tiledBox(1.6, 1.2, 1.6, 1.5, 1.5), mat('crate'), c.x + 0.3, 2.2, c.z - 0.2, [1.6, 1.2, 1.6])
        } else {
          for (const [ox, oz, s] of [[0, 0, 1], [0.9, 0.5, 0.7], [-0.7, 0.7, 0.6]]) {
            const egg = new THREE.Mesh(new THREE.SphereGeometry(0.8 * s, 14, 10), eggMat)
            egg.scale.y = 1.5
            egg.position.set(c.x + ox, 1.0 * s, c.z + oz)
            group.add(egg)
          }
          colliders.push(new THREE.Box3(new THREE.Vector3(c.x - 1.2, 0, c.z - 1.2), new THREE.Vector3(c.x + 1.2, 1.9, c.z + 1.2)))
        }
      }
    // pods and windows
    const stars = document.createElement('canvas')
    stars.width = stars.height = 256
    const sg = stars.getContext('2d')!
    sg.fillStyle = '#02030a'
    sg.fillRect(0, 0, 256, 256)
    for (let i = 0; i < 160; i++) {
      sg.fillStyle = `rgba(255,255,255,${0.3 + Math.random() * 0.7})`
      sg.fillRect(Math.random() * 256, Math.random() * 256, 1 + Math.random() * 2, 1 + Math.random() * 2)
    }
    const planet = sg.createRadialGradient(180, 150, 5, 180, 150, 60)
    planet.addColorStop(0, '#4a7a9a')
    planet.addColorStop(1, '#0a1a30')
    sg.fillStyle = planet
    sg.beginPath()
    sg.arc(180, 150, 55, 0, 7)
    sg.fill()
    const starTex = new THREE.CanvasTexture(stars)
    starTex.colorSpace = THREE.SRGBColorSpace
    const fluid = glow(0x35ff9a)
    const glass = new THREE.MeshLambertMaterial({ color: 0x66ffcc, transparent: true, opacity: 0.25 })
    const dark = new THREE.MeshStandardMaterial({ color: 0x20262e, metalness: 0.8, roughness: 0.3 })
    const embryoMat = new THREE.MeshStandardMaterial({ color: 0x2c5a40, emissive: 0x1a6a40, roughness: 0.4 })
    faces.forEach((f) => {
      if (f.d % 8 === 0) {
        const g = new THREE.Group()
        g.position.set(f.x + f.nx * 0.7, 0, f.z + f.nz * 0.7)
        const base = new THREE.Mesh(new THREE.CylinderGeometry(0.75, 0.85, 0.3, 14), dark)
        base.position.y = 0.15
        const tube = new THREE.Mesh(new THREE.CylinderGeometry(0.62, 0.62, 2.6, 14, 1, true), glass)
        tube.position.y = 1.6
        const core = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.55, 2.5, 12), new THREE.MeshBasicMaterial({ color: 0x0f6a44, transparent: true, opacity: 0.55 }))
        core.position.y = 1.6
        const emb = new THREE.Mesh(new THREE.SphereGeometry(0.28, 10, 8), embryoMat)
        emb.position.y = 1.7
        emb.scale.y = 1.6
        const head = new THREE.Mesh(new THREE.SphereGeometry(0.2, 10, 8), embryoMat)
        head.position.y = 2.3
        head.scale.set(0.9, 1.2, 1.6)
        const topc = new THREE.Mesh(new THREE.CylinderGeometry(0.8, 0.7, 0.3, 14), dark)
        topc.position.y = 3.0
        g.add(base, core, tube, emb, head, topc)
        group.add(g)
        void fluid
        colliders.push(new THREE.Box3(new THREE.Vector3(g.position.x - 0.7, 0, g.position.z - 0.7), new THREE.Vector3(g.position.x + 0.7, 3.2, g.position.z + 0.7)))
        updaters.push((_dt, t) => {
          emb.position.y = 1.7 + Math.sin(t * 0.8 + f.d) * 0.08
        })
      } else if (f.d % 8 === 3) {
        const win = new THREE.Mesh(new THREE.PlaneGeometry(2.6, 1.5), new THREE.MeshBasicMaterial({ map: starTex }))
        win.position.set(f.x, 2.0, f.z)
        win.rotation.y = f.rot
        const fr = new THREE.Mesh(new THREE.BoxGeometry(2.8, 1.7, 0.08), dark)
        fr.position.set(f.x - f.nx * 0.01, 2.0, f.z - f.nz * 0.01)
        fr.rotation.y = f.rot
        group.add(fr, win)
      }
    })
  }

  // ---- exit marker ----
  const exit = nav.find('E')[0]
  const exitGroup = new THREE.Group()
  exitGroup.position.set(exit.x, 0, exit.z)
  const beamMat = new THREE.MeshBasicMaterial({ color: 0xff3030, transparent: true, opacity: 0.28, side: THREE.DoubleSide, depthWrite: false })
  const beam = new THREE.Mesh(new THREE.CylinderGeometry(1.5, 1.5, wallH, 20, 1, true), beamMat)
  beam.position.y = wallH / 2
  const ringMat = new THREE.MeshBasicMaterial({ color: 0xff3030 })
  const ring = new THREE.Mesh(new THREE.TorusGeometry(1.5, 0.08, 8, 28), ringMat)
  ring.rotation.x = Math.PI / 2
  ring.position.y = 0.06
  const label = makeNameTag('EXIT', '#ffffff')
  label.scale.set(2.4, 0.6, 1)
  label.position.y = 2.4
  exitGroup.add(beam, ring, label)
  const exitLight = new THREE.PointLight(0xff3030, 12, 9, 2)
  exitLight.position.y = 1.5
  exitGroup.add(exitLight)
  group.add(exitGroup)
  updaters.push((_dt, t) => {
    ring.scale.setScalar(1 + Math.sin(t * 3) * 0.05)
    beam.rotation.y = t * 0.5
  })
  const setExitOpen = (open: boolean) => {
    const c = open ? 0x30ff70 : 0xff3030
    beamMat.color.setHex(c)
    ringMat.color.setHex(c)
    exitLight.color.setHex(c)
    beamMat.opacity = open ? 0.42 : 0.2
  }

  const map: GameMap = {
    kind,
    name: cfg.name,
    group,
    nav,
    colliders,
    wallH,
    playerSpawn: nav.find('P')[0],
    monsterSpawn: nav.find('M')[0],
    exit,
    cells: nav.find('c'),
    botSpawns: nav.find('b'),
    variant: cfg.variant,
    fogColor: cfg.fog,
    fogDensity: cfg.fogD,
    headLight: cfg.head,
    setExitOpen,
    exitGroup,
    update: (dt, t) => updaters.forEach((u) => u(dt, t)),
    dispose: () => {
      group.traverse((o) => {
        const m = o as THREE.Mesh
        if (m.geometry) m.geometry.dispose()
      })
    },
  }
  return map
}
