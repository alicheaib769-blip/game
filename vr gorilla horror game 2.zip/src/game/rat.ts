import * as THREE from 'three'
import { Limb, furMaterial } from './gorilla'

export interface RatOpts {
  glow?: number
  fur?: number
  scale?: number
}

const unitSphere = new THREE.SphereGeometry(1, 20, 14)
const unitCyl = new THREE.CylinderGeometry(0.8, 1, 1, 10)
const unitCone = new THREE.ConeGeometry(1, 1, 8)
const whiskerGeo = new THREE.CylinderGeometry(0.35, 1, 1, 4)

function sphere(mat: THREE.Material, sx: number, sy: number, sz: number, x = 0, y = 0, z = 0) {
  const m = new THREE.Mesh(unitSphere, mat)
  m.scale.set(sx, sy, sz)
  m.position.set(x, y, z)
  return m
}
function cone(mat: THREE.Material, r: number, h: number, x: number, y: number, z: number, rx = 0, ry = 0, rz = 0) {
  const m = new THREE.Mesh(unitCone, mat)
  m.scale.set(r, h, r)
  m.position.set(x, y, z)
  m.rotation.set(rx, ry, rz)
  return m
}

/**
 * THE SEWER KING — a giant, legless rat horror.
 * Its lower half is a dragging haunch + whipping tail; it hauls itself
 * entirely on two enormous clawed arms, Gorilla-Tag style.
 * Exposes the same structural interface as Gorilla so Game can drive both.
 */
export class RatMonster {
  root = new THREE.Group()
  upper = new THREE.Group()
  head = new THREE.Group()
  jaw = new THREE.Group()
  hips: THREE.Mesh
  nose: THREE.Mesh
  tailBase = new THREE.Group()
  tailSegs: THREE.Group[] = []
  whiskers: THREE.Mesh[] = []
  armL: Limb
  armR: Limb
  furMat: THREE.MeshStandardMaterial
  skinMat: THREE.MeshStandardMaterial
  fleshMat: THREE.MeshStandardMaterial
  eyeMats: THREE.MeshBasicMaterial[] = []
  light: THREE.PointLight
  scale: number
  monsterLike = true
  t = Math.random() * 10
  phase = Math.random() * 6
  pose: 'idle' | 'attack' | 'roar' | 'slam' | 'grab' = 'idle'
  poseT = 0
  poseDur = 1
  jawOpen = 0
  private shL = new THREE.Vector3()
  private shR = new THREE.Vector3()
  private hL = new THREE.Vector3()
  private hR = new THREE.Vector3()
  private poleL = new THREE.Vector3(-1, -0.35, -0.5)
  private poleR = new THREE.Vector3(1, -0.35, -0.5)

  constructor(public opts: RatOpts = {}) {
    const glow = opts.glow ?? 0xff2222
    const furC = opts.fur ?? 0x463a33
    this.scale = opts.scale ?? 2.0

    this.furMat = furMaterial(furC)
    this.skinMat = new THREE.MeshStandardMaterial({ color: 0xa08c82, roughness: 0.5, metalness: 0.02 })
    this.fleshMat = new THREE.MeshStandardMaterial({ color: 0x7a1420, roughness: 0.3 })
    const fur = this.furMat
    const skin = this.skinMat
    const pinkDark = new THREE.MeshStandardMaterial({ color: 0xb06a70, roughness: 0.55 })
    const noseMat = new THREE.MeshStandardMaterial({ color: 0xc77b82, roughness: 0.4 })
    const bone = new THREE.MeshStandardMaterial({ color: 0xd8c89a, roughness: 0.5 })
    const dark = new THREE.MeshStandardMaterial({ color: 0x201814, roughness: 0.7 })

    // ---- dragging hindquarters (NO LEGS) ----
    this.hips = sphere(fur, 0.48, 0.4, 0.58, 0, 0.38, -0.28)
    this.root.add(this.hips)
    this.root.add(sphere(skin, 0.36, 0.24, 0.42, 0, 0.26, -0.42)) // bald haunch patch
    this.root.add(sphere(this.fleshMat, 0.14, 0.1, 0.1, 0.3, 0.5, -0.55)) // scab

    // ---- whipping tail (chained segments) ----
    this.tailBase.position.set(0, 0.44, -0.78)
    let parent: THREE.Object3D = this.tailBase
    for (let i = 0; i < 9; i++) {
      const seg = new THREE.Group()
      seg.position.set(0, -0.012, i === 0 ? 0 : -0.2)
      const r = 0.085 * (1 - i * 0.09)
      const m = new THREE.Mesh(unitCyl, i % 3 === 0 ? skin : pinkDark)
      m.scale.set(r, 0.24, r)
      m.rotation.x = Math.PI / 2
      seg.add(m)
      parent.add(seg)
      this.tailSegs.push(seg)
      parent = seg
    }
    this.root.add(this.tailBase)

    // ---- hunched upper body ----
    const upper = this.upper
    upper.position.set(0, 0.5, 0.15)
    upper.rotation.x = 0.8
    upper.add(sphere(fur, 0.52, 0.44, 0.62, 0, 0.28, -0.1)) // long torso
    upper.add(sphere(fur, 0.58, 0.4, 0.44, 0, 0.54, 0.18)) // huge shoulder hump
    upper.add(sphere(skin, 0.4, 0.36, 0.5, 0, 0.14, 0.0)) // bald belly
    // patchy bald spots on the back
    upper.add(sphere(skin, 0.16, 0.05, 0.2, -0.22, 0.62, -0.28))
    upper.add(sphere(skin, 0.13, 0.05, 0.16, 0.26, 0.58, -0.42))
    upper.add(sphere(skin, 0.1, 0.04, 0.12, 0.05, 0.66, -0.05))
    // open sores
    upper.add(sphere(this.fleshMat, 0.13, 0.16, 0.06, 0.42, 0.32, 0.1))
    upper.add(sphere(this.fleshMat, 0.11, 0.13, 0.06, -0.44, 0.3, -0.1))
    // protruding spine
    for (let i = 0; i < 8; i++) {
      upper.add(cone(dark, 0.045 - i * 0.003, 0.2 + (i % 2) * 0.07, 0, 0.62 - i * 0.012, 0.24 - i * 0.13, -0.55))
    }
    // exposed ribs
    for (const s of [-1, 1]) {
      for (let i = 0; i < 3; i++) {
        const rib = new THREE.Mesh(new THREE.TorusGeometry(0.3, 0.016, 6, 14, Math.PI * 0.7), bone)
        rib.position.set(s * 0.2, 0.24 + i * 0.12, 0.02)
        rib.rotation.set(0, s > 0 ? Math.PI * 0.12 : Math.PI * 1.08, 0.25)
        upper.add(rib)
      }
    }

    // ---- head ----
    const head = this.head
    head.position.set(0, 0.72, 0.55)
    head.rotation.x = -0.45
    head.add(sphere(fur, 0.21, 0.2, 0.27)) // skull
    head.add(sphere(dark, 0.17, 0.07, 0.13, 0, 0.11, 0.15)) // heavy brow ridge
    head.add(sphere(skin, 0.12, 0.1, 0.21, 0, -0.05, 0.3)) // snout
    this.nose = sphere(noseMat, 0.06, 0.05, 0.05, 0, -0.07, 0.5)
    head.add(this.nose)
    // glowing eyes
    const eyeM = new THREE.MeshBasicMaterial({ color: glow })
    this.eyeMats.push(eyeM)
    for (const s of [-1, 1]) {
      head.add(sphere(eyeM, 0.036, 0.03, 0.02, s * 0.1, 0.05, 0.19))
      head.add(sphere(skin, 0.055, 0.04, 0.02, s * 0.105, 0.05, 0.17)) // socket ring
    }
    // huge round ears
    for (const s of [-1, 1]) {
      const ear = sphere(skin, 0.12, 0.15, 0.035, s * 0.17, 0.19, -0.04)
      ear.rotation.z = -s * 0.3
      head.add(ear)
      const inner = sphere(pinkDark, 0.08, 0.11, 0.02, s * 0.17, 0.19, -0.02)
      inner.rotation.z = -s * 0.3
      head.add(inner)
    }
    // whiskers
    const whiskMat = new THREE.MeshBasicMaterial({ color: 0xd8d8d8, transparent: true, opacity: 0.55 })
    for (const s of [-1, 1]) {
      for (let i = 0; i < 3; i++) {
        const w = new THREE.Mesh(whiskerGeo, whiskMat)
        w.scale.set(0.004, 0.32, 0.004)
        w.position.set(s * 0.08, -0.07 + i * 0.02, 0.42)
        w.rotation.set(0.1 - i * 0.14, s * 0.25, s * (1.3 + i * 0.22))
        w.userData.bz = w.rotation.z
        head.add(w)
        this.whiskers.push(w)
      }
    }
    // upper incisors + teeth
    for (const s of [-1, 1]) head.add(cone(bone, 0.024, 0.14, s * 0.033, -0.15, 0.4, Math.PI))
    for (let i = -2; i <= 2; i++) {
      if (Math.abs(i) < 1) continue
      head.add(cone(bone, 0.011, 0.05, i * 0.035, -0.12, 0.36 - Math.abs(i) * 0.02, Math.PI))
    }
    // jaw (animates open/closed)
    const jaw = this.jaw
    jaw.position.set(0, -0.11, 0.14)
    jaw.add(sphere(skin, 0.1, 0.045, 0.18, 0, -0.01, 0.13))
    for (const s of [-1, 1]) jaw.add(cone(bone, 0.02, 0.11, s * 0.03, 0.03, 0.26))
    for (let i = -2; i <= 2; i++) {
      if (Math.abs(i) < 1) continue
      jaw.add(cone(bone, 0.009, 0.04, i * 0.032, 0.02, 0.2 - Math.abs(i) * 0.015))
    }
    jaw.add(sphere(new THREE.MeshBasicMaterial({ color: 0x38060a }), 0.07, 0.03, 0.1, 0, 0.01, 0.1)) // maw
    head.add(jaw)
    upper.add(head)

    // ---- two enormous arms (the ONLY way it moves) ----
    const clawMat = new THREE.MeshStandardMaterial({ color: 0xd8cdb2, roughness: 0.35 })
    this.armL = new Limb(skin, new THREE.MeshStandardMaterial({ color: 0x8a746c, roughness: 0.5 }), 0.92, 0.86, 0.16, clawMat)
    this.armR = new Limb(skin, new THREE.MeshStandardMaterial({ color: 0x8a746c, roughness: 0.5 }), 0.92, 0.86, 0.16, clawMat)
    this.root.add(this.armL.group, this.armR.group)

    this.light = new THREE.PointLight(glow, 6, 14, 1.8)
    this.light.position.set(0, 1.7, 0.5)
    this.root.add(this.light)

    this.root.scale.setScalar(this.scale)
    this.root.traverse((o) => ((o as THREE.Mesh).frustumCulled = false))
    this.animate(0, 0)
  }

  startPose(p: 'attack' | 'roar' | 'slam' | 'grab', dur: number) {
    this.pose = p
    this.poseT = dur
    this.poseDur = dur
  }

  setEyeGlow(v: number) {
    this.eyeMats.forEach((m) => m.color.setScalar(0).add(new THREE.Color(this.opts.glow ?? 0xff2222).multiplyScalar(v)))
  }

  animate(dt: number, speed: number) {
    this.t += dt
    const mv = Math.min(1, speed / 4)
    this.phase += dt * (1.3 + speed * 1.1) * (speed > 0.2 ? 1 : 0)
    const bob = Math.abs(Math.sin(this.phase)) * 0.09 * mv
    this.upper.position.y = 0.5 + bob + Math.sin(this.t * 2.1) * 0.012
    this.upper.rotation.x = 0.8 - mv * 0.12 + Math.sin(this.t * 2.1) * 0.02
    this.hips.position.y = 0.38 + Math.abs(Math.sin(this.phase + 0.6)) * 0.05 * mv
    this.hips.rotation.z = Math.sin(this.phase) * 0.05 * mv
    this.head.rotation.x = -0.45 + Math.sin(this.t * 1.7) * 0.045
    this.head.rotation.z = Math.sin(this.t * 0.9) * 0.03
    this.nose.scale.y = 0.9 + Math.abs(Math.sin(this.t * 7.3)) * 0.35
    for (let i = 0; i < this.whiskers.length; i++) {
      const w = this.whiskers[i]
      w.rotation.z = w.userData.bz + Math.sin(this.t * 8 + i) * 0.05
    }

    let openTarget = 0.06
    if (Math.sin(this.t * 0.7) > 0.985) openTarget = 0.4 // idle jaw snap

    if (this.pose !== 'idle') {
      this.poseT -= dt
      if (this.poseT <= 0) this.pose = 'idle'
      else {
        const k = 1 - this.poseT / this.poseDur
        const sw = Math.sin(Math.min(1, k * 1.5) * Math.PI)
        if (this.pose === 'attack') {
          this.hR.set(0.6 - k * 1.3, 2.0 - k * 1.7, 0.3 + sw * 1.5)
          this.hL.set(-0.7, 0.9 - sw * 0.5, 0.5 + sw * 0.9)
          openTarget = 0.5
        } else if (this.pose === 'roar') {
          const r = Math.sin(Math.min(1, k * 1.2) * Math.PI)
          this.upper.rotation.x = 0.8 - r * 1.15
          this.head.rotation.x = -0.45 - r * 0.55
          this.hL.set(-0.95 - r * 0.25, 0.6 + r * 1.7, 0.25)
          this.hR.set(0.95 + r * 0.25, 0.6 + r * 1.7, 0.25)
          openTarget = 1
        } else if (this.pose === 'slam') {
          if (k < 0.45) {
            const q = k / 0.45
            this.hL.set(-0.5, 0.4 + q * 1.9, 0.2)
            this.hR.set(0.5, 0.4 + q * 1.9, 0.2)
            this.upper.rotation.x = 0.8 - q * 0.25
          } else {
            const q = Math.min(1, (k - 0.45) / 0.2)
            this.hL.set(-0.55, 2.3 - q * 2.25, 0.2 + q * 0.75)
            this.hR.set(0.55, 2.3 - q * 2.25, 0.2 + q * 0.75)
            this.upper.rotation.x = 0.8 + q * 0.35
            openTarget = 0.9
          }
        } else if (this.pose === 'grab') {
          const q = Math.min(1, k * 1.4)
          this.hL.set(-0.5 + q * 0.32, 1.3 - q * 0.75, 0.4 + q * 0.85)
          this.hR.set(0.5 - q * 0.32, 1.3 - q * 0.75, 0.4 + q * 0.85)
          openTarget = 0.45
        }
      }
    }

    // default arm-swing locomotion (arms ONLY — no legs)
    if (this.pose === 'idle') {
      const sw2 = 0.65
      for (const s of [-1, 1] as const) {
        const p = this.phase + (s > 0 ? 0 : Math.PI)
        const h = s > 0 ? this.hR : this.hL
        h.set(s * 0.68, 0.12 + mv * Math.max(0, Math.cos(p)) * 0.42, 0.55 + mv * sw2 * Math.sin(p))
      }
    }

    this.jawOpen += (openTarget - this.jawOpen) * Math.min(1, dt * 9)
    this.jaw.rotation.x = 0.18 + this.jawOpen * 0.6

    this.upper.updateMatrix()
    this.shL.set(-0.5, 0.5, 0.28).applyMatrix4(this.upper.matrix)
    this.shR.set(0.5, 0.5, 0.28).applyMatrix4(this.upper.matrix)
    this.armL.update(this.shL, this.hL, this.poleL)
    this.armR.update(this.shR, this.hR, this.poleR)

    // tail whip
    this.tailBase.rotation.y = Math.sin(this.t * 1.15) * (0.25 + mv * 0.35)
    for (let i = 0; i < this.tailSegs.length; i++) {
      const s = this.tailSegs[i]
      s.rotation.y = Math.sin(this.t * 2.3 + i * 0.55) * 0.05 * (i + 2)
      s.rotation.x = Math.sin(this.t * 1.4 + i * 0.4) * 0.02
    }

    if (this.light) this.light.intensity = 5 + Math.sin(this.t * 11) * 1.6
  }

  dispose() {
    this.root.traverse((o) => {
      const m = o as THREE.Mesh
      if (m.geometry && m.geometry !== unitSphere && m.geometry !== unitCyl && m.geometry !== unitCone && m.geometry !== whiskerGeo) m.geometry.dispose()
    })
  }
}
