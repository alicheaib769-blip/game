import * as THREE from 'three'

export type MonsterVariant = 'possessed' | 'entity' | 'xeno'

export interface GorillaOpts {
  fur: number
  face?: number
  belly?: number
  accent?: number
  cosmetic?: number // 0 none, 1 beanie, 2 headband, 3 shades, 4 backpack + cap
  monster?: MonsterVariant
  scale?: number
  cute?: boolean // small, big-headed, doe-eyed baby gorilla
}

let furTex: THREE.CanvasTexture | null = null
function getFurTexture() {
  if (furTex) return furTex
  const c = document.createElement('canvas')
  c.width = c.height = 128
  const g = c.getContext('2d')!
  g.fillStyle = '#b9b9b9'
  g.fillRect(0, 0, 128, 128)
  for (let i = 0; i < 2600; i++) {
    const l = 70 + Math.random() * 185
    g.strokeStyle = `rgba(${l},${l},${l},${0.25 + Math.random() * 0.4})`
    g.lineWidth = 1
    const x = Math.random() * 128
    const y = Math.random() * 128
    g.beginPath()
    g.moveTo(x, y)
    g.lineTo(x + (Math.random() - 0.5) * 3, y + 3 + Math.random() * 7)
    g.stroke()
  }
  furTex = new THREE.CanvasTexture(c)
  furTex.wrapS = furTex.wrapT = THREE.RepeatWrapping
  furTex.colorSpace = THREE.SRGBColorSpace
  return furTex
}

export function furMaterial(color: number, emissive = 0x000000) {
  return new THREE.MeshStandardMaterial({
    color,
    map: getFurTexture(),
    roughness: 0.95,
    metalness: 0,
    emissive,
    emissiveIntensity: 0.25,
  })
}
function skinMaterial(color: number) {
  return new THREE.MeshStandardMaterial({ color, roughness: 0.6, metalness: 0.05 })
}
function glowMaterial(color: number) {
  return new THREE.MeshBasicMaterial({ color })
}

const UP = new THREE.Vector3(0, 1, 0)
const _d = new THREE.Vector3()
const _dir = new THREE.Vector3()
const _p = new THREE.Vector3()
const _e = new THREE.Vector3()
const _h = new THREE.Vector3()
const unitCyl = new THREE.CylinderGeometry(0.8, 1, 1, 12)
const unitSphere = new THREE.SphereGeometry(1, 20, 14)
const unitCone = new THREE.ConeGeometry(1, 1, 8)

function sphere(mat: THREE.Material, sx: number, sy: number, sz: number, x = 0, y = 0, z = 0) {
  const m = new THREE.Mesh(unitSphere, mat)
  m.scale.set(sx, sy, sz)
  m.position.set(x, y, z)
  return m
}
function cone(mat: THREE.Material, r: number, h: number, x: number, y: number, z: number, rx = 0, ry = 0, rz = 0) {
  const m = new THREE.Mesh(unitCone, mat)
  m.scale.set(r, h, r)
  m.position.set(x, y, z)
  m.rotation.set(rx, ry, rz)
  return m
}

/** Two-bone IK arm built from tapered cylinders and a big fist. */
export class Limb {
  group = new THREE.Group()
  private upper: THREE.Mesh
  private fore: THREE.Mesh
  private elbow: THREE.Mesh
  private shoulder: THREE.Mesh
  fist: THREE.Group
  constructor(
    mat: THREE.Material,
    fistMat: THREE.Material,
    private L1 = 0.75,
    private L2 = 0.75,
    private r1 = 0.15,
    claws?: THREE.Material,
  ) {
    this.upper = new THREE.Mesh(unitCyl, mat)
    this.fore = new THREE.Mesh(unitCyl, mat)
    this.elbow = sphere(mat, r1 * 0.95, r1 * 0.95, r1 * 0.95)
    this.shoulder = sphere(mat, r1 * 1.25, r1 * 1.25, r1 * 1.25)
    this.fist = new THREE.Group()
    const f = sphere(fistMat, r1 * 1.05, r1 * 0.9, r1 * 1.15)
    this.fist.add(f)
    // knuckles
    for (let i = -1; i <= 1; i++) this.fist.add(sphere(fistMat, r1 * 0.32, r1 * 0.32, r1 * 0.32, i * r1 * 0.6, -r1 * 0.2, r1 * 1.0))
    if (claws) for (let i = -1; i <= 1; i++) this.fist.add(cone(claws, r1 * 0.2, r1 * 1.8, i * r1 * 0.55, -r1 * 0.35, r1 * 1.5, Math.PI / 2 + 0.5))
    this.group.add(this.upper, this.fore, this.elbow, this.shoulder, this.fist)
    this.group.traverse((o) => ((o as THREE.Mesh).frustumCulled = false))
  }
  private seg(m: THREE.Mesh, a: THREE.Vector3, b: THREE.Vector3, r0: number, r1: number) {
    _d.subVectors(b, a)
    const len = _d.length() || 0.001
    m.position.copy(a).addScaledVector(_d, 0.5)
    m.quaternion.setFromUnitVectors(UP, _d.divideScalar(len))
    // cylinder: top radius 0.8 (toward b), bottom 1 (toward a); use r0 at a, r1 at b average
    m.scale.set(r0, len, r0)
    void r1
  }
  /** S = shoulder, H = hand target, pole = elbow direction hint */
  update(S: THREE.Vector3, H: THREE.Vector3, pole: THREE.Vector3) {
    _dir.subVectors(H, S)
    let dist = _dir.length()
    if (dist < 1e-4) {
      _dir.set(0, -1, 0)
      dist = 0.05
    } else _dir.divideScalar(dist)
    const reach = this.L1 + this.L2 - 0.003
    dist = Math.min(dist, reach)
    dist = Math.max(dist, Math.abs(this.L1 - this.L2) + 0.05)
    _h.copy(S).addScaledVector(_dir, dist)
    const a = (this.L1 * this.L1 - this.L2 * this.L2 + dist * dist) / (2 * dist)
    const hh = Math.sqrt(Math.max(0, this.L1 * this.L1 - a * a))
    _p.copy(pole).addScaledVector(_dir, -pole.dot(_dir))
    if (_p.lengthSq() < 1e-6) _p.set(0, 0, 1).addScaledVector(_dir, -_dir.z)
    _p.normalize()
    _e.copy(S).addScaledVector(_dir, a).addScaledVector(_p, hh)
    this.seg(this.upper, S, _e, this.r1, this.r1)
    this.seg(this.fore, _e, _h, this.r1 * 0.88, this.r1)
    this.shoulder.position.copy(S)
    this.elbow.position.copy(_e)
    this.fist.position.copy(_h)
    // orient fist along forearm
    _d.subVectors(_h, _e).normalize()
    this.fist.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), _d)
  }
}

interface Theme {
  fur: number
  skin: number
  flesh: number
  glow: number
  eye: number
}
const THEMES: Record<MonsterVariant, Theme> = {
  possessed: { fur: 0x1c1416, skin: 0x8a8f96, flesh: 0x6b0a0e, glow: 0xff2222, eye: 0xfff2d0 },
  entity: { fur: 0x6a5230, skin: 0xd3a77a, flesh: 0x8c2a1e, glow: 0xffe14a, eye: 0xffe14a },
  xeno: { fur: 0x0b1015, skin: 0x1c2630, flesh: 0x0a5a4c, glow: 0x34ffd0, eye: 0x34ffd0 },
}

export class Gorilla {
  root = new THREE.Group()
  upper = new THREE.Group()
  head = new THREE.Group()
  legs: THREE.Group[] = []
  armL: Limb
  armR: Limb
  furMat: THREE.MeshStandardMaterial
  skinMat: THREE.MeshStandardMaterial
  fleshMat: THREE.MeshStandardMaterial
  eyeMats: THREE.MeshBasicMaterial[] = []
  scale: number
  theme?: Theme
  light?: THREE.PointLight
  phase = Math.random() * 6
  t = Math.random() * 10
  pose: 'idle' | 'attack' | 'roar' = 'idle'
  poseT = 0
  frozenPose = false
  monsterLike = false
  private shL = new THREE.Vector3()
  private shR = new THREE.Vector3()
  private hL = new THREE.Vector3()
  private hR = new THREE.Vector3()
  private poleL = new THREE.Vector3(-1, -0.15, -0.5)
  private poleR = new THREE.Vector3(1, -0.15, -0.5)

  constructor(public opts: GorillaOpts) {
    const th = opts.monster ? THEMES[opts.monster] : undefined
    this.theme = th
    this.monsterLike = !!opts.monster
    this.scale = opts.scale ?? (opts.monster ? 1.45 : opts.cute ? 0.72 : 1)
    const furC = th ? th.fur : opts.fur
    const skinC = th ? th.skin : (opts.face ?? 0x2a2224)
    this.furMat = furMaterial(furC, th ? 0x000000 : 0x000000)
    this.skinMat = skinMaterial(skinC)
    this.fleshMat = new THREE.MeshStandardMaterial({ color: th ? th.flesh : (opts.accent ?? 0x444444), roughness: 0.35, metalness: 0.1 })
    const bellyMat = opts.belly !== undefined && !th ? furMaterial(opts.belly) : this.furMat
    const fur = this.furMat
    const skin = this.skinMat
    const upper = this.upper
    upper.position.set(0, 0.8, 0)
    upper.rotation.x = 0.5

    // torso
    upper.add(sphere(fur, 0.58, 0.5, 0.48, 0, 0.42, 0))
    upper.add(sphere(fur, 0.62, 0.38, 0.45, 0, 0.72, -0.06)) // shoulder hump
    upper.add(sphere(bellyMat, 0.46, 0.46, 0.42, 0, 0.08, 0.06))
    upper.add(sphere(skin, 0.3, 0.3, 0.14, 0, 0.5, 0.4)) // bare chest
    // saddle / back patch
    upper.add(sphere(opts.monster ? this.fleshMat : (opts.belly !== undefined ? bellyMat : fur), 0.4, 0.2, 0.34, 0, 0.72, -0.34))
    // hips
    const hips = sphere(fur, 0.42, 0.34, 0.38, 0, 0.74, -0.12)
    this.root.add(hips)
    this.root.add(upper)

    // head
    const head = this.head
    head.position.set(0, 0.97, 0.28)
    head.rotation.x = -0.35
    head.add(sphere(fur, 0.2, 0.19, 0.21))
    head.add(sphere(fur, 0.08, 0.14, 0.17, 0, 0.14, -0.04)) // sagittal crest
    const brow = new THREE.Mesh(new THREE.CapsuleGeometry(0.035, 0.27, 4, 8), skin)
    brow.rotation.z = Math.PI / 2
    brow.position.set(0, 0.07, 0.165)
    head.add(brow)
    head.add(sphere(skin, 0.14, 0.11, 0.12, 0, -0.06, 0.17)) // muzzle
    head.add(sphere(this.furMat, 0.15, 0.06, 0.1, 0, -0.17, 0.12)) // beard/jaw
    for (const s of [-1, 1]) {
      head.add(sphere(new THREE.MeshBasicMaterial({ color: 0x000000 }), 0.016, 0.012, 0.012, s * 0.035, -0.035, 0.285))
      head.add(sphere(skin, 0.05, 0.06, 0.02, s * 0.2, 0, 0)) // ears
    }
    // eyes
    const eyeColor = th ? th.eye : 0xe9b04a
    if (opts.cute) {
      // big doe eyes: white sclera, huge dark pupil, glint
      const sclera = glowMaterial(0xffffff)
      const pupil = glowMaterial(0x181012)
      const glint = glowMaterial(0xffffff)
      for (const s of [-1, 1]) {
        head.add(sphere(skin, 0.058, 0.054, 0.034, s * 0.082, 0.045, 0.185))
        head.add(sphere(sclera, 0.046, 0.044, 0.026, s * 0.082, 0.045, 0.2))
        head.add(sphere(pupil, 0.027, 0.03, 0.018, s * 0.082, 0.045, 0.224))
        head.add(sphere(glint, 0.009, 0.009, 0.006, s * 0.082 + 0.013, 0.062, 0.238))
      }
      // rosy cheeks
      const blush = new THREE.MeshStandardMaterial({ color: 0xe88a9a, roughness: 0.8 })
      head.add(sphere(blush, 0.038, 0.026, 0.02, -0.125, -0.045, 0.15))
      head.add(sphere(blush, 0.038, 0.026, 0.02, 0.125, -0.045, 0.15))
    } else {
      for (const s of [-1, 1]) {
        head.add(sphere(skin, 0.05, 0.045, 0.03, s * 0.075, 0.04, 0.19)) // socket
        const em = glowMaterial(th ? th.glow : 0x120a05)
        if (!th) {
          const white = glowMaterial(eyeColor)
          const m = sphere(white, 0.026, 0.026, 0.02, s * 0.075, 0.04, 0.21)
          head.add(m)
          head.add(sphere(em, 0.012, 0.014, 0.01, s * 0.075, 0.04, 0.226))
        } else {
          const eyeM = glowMaterial(th.glow)
          this.eyeMats.push(eyeM)
          head.add(sphere(eyeM, 0.034, 0.03, 0.02, s * 0.075, 0.04, 0.21))
        }
      }
    }
    // mouth
    const mouthMat = new THREE.MeshBasicMaterial({ color: opts.monster ? 0x2a0508 : 0x120808 })
    if (opts.monster) {
      const jaw = new THREE.Group()
      jaw.position.set(0, -0.12, 0.08)
      jaw.rotation.x = 0.55
      jaw.add(sphere(skin, 0.1, 0.04, 0.13, 0, -0.01, 0.07))
      const white = new THREE.MeshStandardMaterial({ color: 0xe8e0c8, roughness: 0.5 })
      for (let i = -3; i <= 3; i++) jaw.add(cone(white, 0.012, 0.06 + (Math.abs(i) === 2 ? 0.03 : 0), i * 0.027, 0.03, 0.12, 0, 0, 0))
      for (const s of [-1, 1]) jaw.add(cone(white, 0.02, 0.14, s * 0.07, 0.07, 0.14))
      head.add(jaw)
      head.add(sphere(mouthMat, 0.09, 0.05, 0.1, 0, -0.12, 0.17))
      for (let i = -3; i <= 3; i++) head.add(cone(new THREE.MeshStandardMaterial({ color: 0xe8e0c8 }), 0.012, 0.05, i * 0.027, -0.1, 0.24, Math.PI))
    } else if (opts.cute) {
      const smile = new THREE.Mesh(new THREE.TorusGeometry(0.04, 0.009, 6, 12, Math.PI * 0.7), mouthMat)
      smile.position.set(0, -0.09, 0.24)
      smile.rotation.set(0.35, 0, Math.PI * 1.15)
      head.add(smile)
    } else {
      const mouth = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.012, 0.01), mouthMat)
      mouth.position.set(0, -0.115, 0.255)
      head.add(mouth)
    }
    if (opts.cute) head.scale.setScalar(1.38) // big baby head
    upper.add(head)

    // monster extras
    if (opts.monster && th) {
      const bone = new THREE.MeshStandardMaterial({ color: 0xd8cfb6, roughness: 0.6 })
      const dark = new THREE.MeshStandardMaterial({ color: 0x0b0b0e, roughness: 0.3, metalness: 0.4 })
      for (const s of [-1, 1]) {
        head.add(cone(opts.monster === 'xeno' ? dark : bone, 0.04, 0.34, s * 0.12, 0.26, -0.02, -0.3, 0, -s * 0.5))
      }
      // spine spikes
      for (let i = 0; i < 7; i++) {
        upper.add(cone(opts.monster === 'xeno' ? new THREE.MeshBasicMaterial({ color: th.glow }) : bone, 0.04 - i * 0.002, 0.17 + (i % 2) * 0.05, 0, 0.0 + i * 0.12, -0.44 - (i === 5 ? 0.03 : 0), -0.9))
      }
      // ribs
      for (const s of [-1, 1]) {
        for (let i = 0; i < 4; i++) {
          const rib = new THREE.Mesh(new THREE.TorusGeometry(0.34, 0.017, 6, 14, Math.PI * 0.8), bone)
          rib.position.set(s * 0.15, 0.2 + i * 0.1, 0.05)
          rib.rotation.set(0, s * (Math.PI / 2) - s * 0.2, 0.2)
          rib.rotation.y = s > 0 ? Math.PI * 0.1 : Math.PI * 1.1
          upper.add(rib)
        }
        // wounds
        upper.add(sphere(this.fleshMat, 0.18, 0.2, 0.08, s * 0.3, 0.3, 0.38))
      }
      // glowing veins
      const vein = glowMaterial(th.glow)
      for (let i = 0; i < 6; i++) {
        const v = new THREE.Mesh(new THREE.CapsuleGeometry(0.008, 0.2 + i * 0.03, 3, 5), vein)
        v.position.set((i - 2.5) * 0.12, 0.42 + (i % 2) * 0.08, 0.45 - Math.abs(i - 2.5) * 0.05)
        v.rotation.z = (i - 2.5) * 0.3
        upper.add(v)
        this.eyeMats.push(vein)
      }
      if (opts.monster === 'xeno') {
        head.add(cone(dark, 0.09, 0.45, 0, 0.08, -0.34, -Math.PI / 2 - 0.35))
        head.scale.set(1, 1, 1)
      }
      if (opts.monster === 'entity') {
        const tooth = new THREE.MeshBasicMaterial({ color: 0xf5eed0 })
        for (let i = -6; i <= 6; i++) head.add(sphere(tooth, 0.008, 0.02, 0.006, i * 0.021, -0.1, 0.285 - Math.abs(i) * 0.012))
      }
      if (opts.monster === 'possessed') {
        const chain = new THREE.Mesh(new THREE.TorusGeometry(0.46, 0.025, 6, 20), new THREE.MeshStandardMaterial({ color: 0x555555, metalness: 0.8, roughness: 0.4 }))
        chain.position.set(0, 0.55, 0.05)
        chain.rotation.x = Math.PI / 2
        chain.scale.set(1.1, 1, 0.8)
        upper.add(chain)
      }
      this.light = new THREE.PointLight(th.glow, 5, 12, 1.6)
      this.light.position.set(0, 1.4, 0.3)
      this.root.add(this.light)
    }

    // cosmetics
    const cos = opts.cosmetic ?? 0
    const accentC = opts.accent ?? 0xffffff
    if (!opts.monster) {
      if (cos === 1 || cos === 4) {
        const beanie = sphere(new THREE.MeshStandardMaterial({ color: accentC, roughness: 0.9 }), 0.21, 0.15, 0.22, 0, 0.1, -0.01)
        head.add(beanie)
        head.add(sphere(new THREE.MeshStandardMaterial({ color: 0xffffff }), 0.05, 0.05, 0.05, 0, 0.25, -0.01))
      }
      if (cos === 2) {
        const hb = new THREE.Mesh(new THREE.TorusGeometry(0.2, 0.025, 6, 20), new THREE.MeshStandardMaterial({ color: accentC }))
        hb.rotation.x = Math.PI / 2
        hb.position.set(0, 0.09, 0)
        head.add(hb)
      }
      if (cos === 3) {
        const gm = new THREE.MeshStandardMaterial({ color: 0x050505, roughness: 0.1, metalness: 0.6 })
        for (const s of [-1, 1]) {
          const lens = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.055, 0.015, 14), gm)
          lens.rotation.x = Math.PI / 2
          lens.position.set(s * 0.075, 0.04, 0.225)
          head.add(lens)
        }
        const bar = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.015, 0.015), gm)
        bar.position.set(0, 0.05, 0.225)
        head.add(bar)
      }
      if (cos === 4) {
        const bp = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.5, 0.2), new THREE.MeshStandardMaterial({ color: accentC, roughness: 0.8 }))
        bp.position.set(0, 0.45, -0.5)
        upper.add(bp)
        const pocket = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.2, 0.06), new THREE.MeshStandardMaterial({ color: 0x222222 }))
        pocket.position.set(0, 0.35, -0.62)
        upper.add(pocket)
      }
    }

    // legs
    for (const s of [-1, 1]) {
      const leg = new THREE.Group()
      leg.position.set(s * 0.26, 0.78, -0.08)
      const thigh = new THREE.Mesh(new THREE.CapsuleGeometry(0.17, 0.26, 4, 10), fur)
      thigh.position.y = -0.2
      const shin = new THREE.Mesh(new THREE.CapsuleGeometry(0.125, 0.22, 4, 10), fur)
      shin.position.set(0, -0.48, 0.03)
      const foot = sphere(skin, 0.12, 0.07, 0.19, 0, -0.7, 0.08)
      leg.add(thigh, shin, foot)
      this.legs.push(leg)
      this.root.add(leg)
    }

    // arms (cute = chubby stubs)
    const claws = opts.monster ? new THREE.MeshStandardMaterial({ color: 0xe0d8c0, roughness: 0.4 }) : undefined
    const hand = opts.monster ? skin : skin
    const armL_ = opts.cute ? 0.55 : 0.75
    const armR_ = opts.cute ? 0.105 : 0.15
    this.armL = new Limb(fur, hand, armL_, armL_, armR_, claws)
    this.armR = new Limb(fur, hand, armL_, armL_, armR_, claws)
    this.root.add(this.armL.group, this.armR.group)
    if (opts.cute) this.legs.forEach((l) => l.scale.set(0.9, 0.72, 0.9))
    this.root.scale.setScalar(this.scale)
    this.root.traverse((o) => ((o as THREE.Mesh).frustumCulled = false))
    this.animate(0, 0)
  }

  startPose(p: 'attack' | 'roar' | 'slam' | 'grab', dur: number) {
    // gorillas only know swipe + roar; slam/grab fall back to a swipe
    this.pose = p === 'slam' || p === 'grab' ? 'attack' : p
    this.poseT = dur
    this.poseDur = dur
  }
  private poseDur = 1

  /** Arms-disabled pin pose: slumped, drooping arms, trembling. */
  setFrozen(v: boolean) {
    this.frozenPose = v
  }

  setEyeGlow(v: number) {
    this.eyeMats.forEach((m) => m.color.setScalar(1).multiplyScalar(0).add(new THREE.Color(this.theme!.glow).multiplyScalar(v)))
  }

  animate(dt: number, speed: number) {
    this.t += dt
    if (this.frozenPose) {
      // pinned: arms dead at the sides, hunched, shivering in place
      this.upper.position.y = 0.72
      this.upper.position.x = Math.sin(this.t * 26) * 0.012
      this.upper.rotation.x = 0.95
      this.head.rotation.x = 0.35 + Math.sin(this.t * 3) * 0.05
      this.legs[0].rotation.x = 0.5
      this.legs[1].rotation.x = 0.45
      this.hL.set(-0.5, 0.1, -0.35)
      this.hR.set(0.5, 0.1, -0.35)
      this.upper.updateMatrix()
      this.shL.set(-0.5, 0.6, 0.02).applyMatrix4(this.upper.matrix)
      this.shR.set(0.5, 0.6, 0.02).applyMatrix4(this.upper.matrix)
      this.armL.update(this.shL, this.hL, this.poleL)
      this.armR.update(this.shR, this.hR, this.poleR)
      return
    }
    const mv = Math.min(1, speed / 3.5)
    this.phase += dt * (1.5 + speed * 1.3) * (speed > 0.2 ? 1 : 0)
    const bob = Math.abs(Math.sin(this.phase)) * 0.06 * mv
    this.upper.position.y = 0.8 + bob - (this.pose === 'idle' ? Math.sin(this.t * 2) * 0.006 : 0)
    this.upper.rotation.x = 0.5 - mv * 0.1
    this.upper.updateMatrix()
    this.head.rotation.x = -0.35 + Math.sin(this.t * 1.3) * 0.03
    this.legs[0].rotation.x = Math.sin(this.phase) * 0.7 * mv
    this.legs[1].rotation.x = -Math.sin(this.phase) * 0.7 * mv
    this.legs.forEach((l) => (l.position.y = 0.78))

    const sw = 0.55
    for (const s of [-1, 1] as const) {
      const p = this.phase + (s > 0 ? 0 : Math.PI)
      const h = s > 0 ? this.hR : this.hL
      h.set(s * 0.62, 0.1 + mv * Math.max(0, Math.cos(p)) * 0.38, 0.5 + mv * sw * Math.sin(p))
    }
    if (this.pose !== 'idle') {
      this.poseT -= dt
      if (this.poseT <= 0) this.pose = 'idle'
      else {
        const k = 1 - this.poseT / this.poseDur
        if (this.pose === 'attack') {
          // right claw swipe
          const sw2 = Math.sin(Math.min(1, k * 1.6) * Math.PI)
          this.hR.set(0.5 - k * 1.0, 1.9 - k * 1.5, 0.3 + sw2 * 1.4)
          this.hL.set(-0.7, 1.2 - sw2 * 0.7, 0.6 + sw2 * 1.0)
        } else {
          // roar: arms up and beating chest
          const beat = Math.sin(k * Math.PI * 10) * 0.12
          this.hL.set(-0.38 + beat, 1.5, 0.55)
          this.hR.set(0.38 - beat, 1.5, 0.55)
          this.upper.rotation.x = -0.15
          this.head.rotation.x = 0.4
        }
      }
      this.upper.updateMatrix()
    }
    this.shL.set(-0.5, 0.6, 0.02).applyMatrix4(this.upper.matrix)
    this.shR.set(0.5, 0.6, 0.02).applyMatrix4(this.upper.matrix)
    this.armL.update(this.shL, this.hL, this.poleL)
    this.armR.update(this.shR, this.hR, this.poleR)
    if (this.light) this.light.intensity = 4 + Math.sin(this.t * 9) * 1.2
  }

  dispose() {
    this.root.traverse((o) => {
      const m = o as THREE.Mesh
      if (m.geometry && m.geometry !== unitSphere && m.geometry !== unitCyl && m.geometry !== unitCone) m.geometry.dispose()
    })
  }
}

export function makeNameTag(text: string, color = '#ffffff') {
  const c = document.createElement('canvas')
  c.width = 256
  c.height = 64
  const g = c.getContext('2d')!
  g.font = 'bold 34px sans-serif'
  g.textAlign = 'center'
  g.textBaseline = 'middle'
  g.lineWidth = 6
  g.strokeStyle = 'rgba(0,0,0,0.85)'
  g.strokeText(text, 128, 34)
  g.fillStyle = color
  g.fillText(text, 128, 34)
  const t = new THREE.CanvasTexture(c)
  t.colorSpace = THREE.SRGBColorSpace
  const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: t, transparent: true, depthWrite: false }))
  sp.scale.set(1.3, 0.33, 1)
  return sp
}
