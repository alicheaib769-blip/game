export interface P2 {
  x: number
  z: number
}

export class NavGrid {
  W: number
  H: number
  constructor(public rows: string[], public cell = 4) {
    this.H = rows.length
    this.W = rows[0].length
  }
  at(cx: number, cy: number) {
    if (cx < 0 || cy < 0 || cx >= this.W || cy >= this.H) return '#'
    return this.rows[cy][cx]
  }
  isWall(cx: number, cy: number) {
    return this.at(cx, cy) === '#'
  }
  blocked(cx: number, cy: number) {
    const c = this.at(cx, cy)
    return c === '#' || c === 'o'
  }
  cx(x: number) {
    return Math.floor(x / this.cell)
  }
  center(cx: number, cy: number): P2 {
    return { x: (cx + 0.5) * this.cell, z: (cy + 0.5) * this.cell }
  }
  wallAt(x: number, z: number) {
    return this.isWall(this.cx(x), this.cx(z))
  }
  find(ch: string): P2[] {
    const out: P2[] = []
    for (let y = 0; y < this.H; y++) for (let x = 0; x < this.W; x++) if (this.rows[y][x] === ch) out.push(this.center(x, y))
    return out
  }
  freeCells(): P2[] {
    const out: P2[] = []
    for (let y = 0; y < this.H; y++) for (let x = 0; x < this.W; x++) if (!this.blocked(x, y)) out.push(this.center(x, y))
    return out
  }
  randomFree(): P2 {
    const f = this.freeCells()
    return f[Math.floor(Math.random() * f.length)]
  }

  hasLOS(ax: number, az: number, bx: number, bz: number) {
    const dx = bx - ax
    const dz = bz - az
    const d = Math.hypot(dx, dz)
    const n = Math.ceil(d / 0.8)
    for (let i = 1; i < n; i++) {
      const t = i / n
      if (this.wallAt(ax + dx * t, az + dz * t)) return false
    }
    return true
  }

  private nearestFree(cx: number, cy: number): [number, number] {
    if (!this.blocked(cx, cy)) return [cx, cy]
    for (let r = 1; r < 6; r++) {
      for (let dy = -r; dy <= r; dy++)
        for (let dx = -r; dx <= r; dx++) if (!this.blocked(cx + dx, cy + dy)) return [cx + dx, cy + dy]
    }
    return [cx, cy]
  }

  findPath(sx: number, sz: number, tx: number, tz: number): P2[] {
    const [s0x, s0y] = this.nearestFree(this.cx(sx), this.cx(sz))
    const [t0x, t0y] = this.nearestFree(this.cx(tx), this.cx(tz))
    const W = this.W
    const key = (x: number, y: number) => y * W + x
    const start = key(s0x, s0y)
    const goal = key(t0x, t0y)
    if (start === goal) return [{ x: tx, z: tz }]
    const g = new Map<number, number>([[start, 0]])
    const came = new Map<number, number>()
    const open: [number, number][] = [[0, start]]
    const closed = new Set<number>()
    const h = (x: number, y: number) => Math.hypot(x - t0x, y - t0y)
    let found = false
    while (open.length) {
      let bi = 0
      for (let i = 1; i < open.length; i++) if (open[i][0] < open[bi][0]) bi = i
      const [, cur] = open.splice(bi, 1)[0]
      if (cur === goal) {
        found = true
        break
      }
      if (closed.has(cur)) continue
      closed.add(cur)
      const cx = cur % W
      const cy = Math.floor(cur / W)
      for (let dy = -1; dy <= 1; dy++) {
        for (let dx = -1; dx <= 1; dx++) {
          if (!dx && !dy) continue
          const nx = cx + dx
          const ny = cy + dy
          if (this.blocked(nx, ny)) continue
          if (dx && dy && (this.blocked(cx + dx, cy) || this.blocked(cx, cy + dy))) continue
          const nk = key(nx, ny)
          if (closed.has(nk)) continue
          const ng = g.get(cur)! + (dx && dy ? 1.414 : 1)
          if (ng < (g.get(nk) ?? Infinity)) {
            g.set(nk, ng)
            came.set(nk, cur)
            open.push([ng + h(nx, ny), nk])
          }
        }
      }
    }
    if (!found) return []
    const path: P2[] = []
    let c = goal
    while (c !== start) {
      path.push(this.center(c % W, Math.floor(c / W)))
      c = came.get(c)!
    }
    path.reverse()
    if (path.length && t0x === this.cx(tx) && t0y === this.cx(tz)) path[path.length - 1] = { x: tx, z: tz }
    return path
  }
}
