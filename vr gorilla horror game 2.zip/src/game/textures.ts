import * as THREE from 'three'

const cache = new Map<string, THREE.CanvasTexture>()

function rng(seed: number) {
  let s = seed >>> 0
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0
    return s / 4294967296
  }
}

function make(key: string, size: number, draw: (g: CanvasRenderingContext2D, s: number, r: () => number) => void) {
  const hit = cache.get(key)
  if (hit) return hit
  const c = document.createElement('canvas')
  c.width = c.height = size
  const g = c.getContext('2d')!
  draw(g, size, rng(key.length * 7919 + key.charCodeAt(0) * 31))
  const t = new THREE.CanvasTexture(c)
  t.wrapS = t.wrapT = THREE.RepeatWrapping
  t.colorSpace = THREE.SRGBColorSpace
  t.anisotropy = 4
  cache.set(key, t)
  return t
}

function speckle(g: CanvasRenderingContext2D, s: number, r: () => number, n: number, dark = true, a = 0.12) {
  for (let i = 0; i < n; i++) {
    g.fillStyle = dark ? `rgba(0,0,0,${r() * a})` : `rgba(255,255,255,${r() * a})`
    g.fillRect(r() * s, r() * s, 1 + r() * 3, 1 + r() * 3)
  }
}

export type TexKind =
  | 'backWall' | 'backFloor' | 'backCeil'
  | 'manWall' | 'manFloor' | 'manCeil'
  | 'shipWall' | 'shipFloor' | 'shipCeil'
  | 'wood' | 'crate' | 'pillar' | 'bookshelf' | 'alienFlesh'

export function getTexture(kind: TexKind): THREE.CanvasTexture {
  switch (kind) {
    case 'backWall':
      return make(kind, 256, (g, s, r) => {
        g.fillStyle = '#c4ad55'
        g.fillRect(0, 0, s, s)
        for (let x = 0; x < s; x += 16) {
          g.fillStyle = x % 32 === 0 ? 'rgba(120,96,20,0.22)' : 'rgba(255,240,150,0.10)'
          g.fillRect(x, 0, 8, s)
        }
        for (let i = 0; i < 6; i++) {
          const gr = g.createRadialGradient(r() * s, r() * s, 2, r() * s, r() * s, 60)
          gr.addColorStop(0, 'rgba(70,50,10,0.35)')
          gr.addColorStop(1, 'rgba(70,50,10,0)')
          g.fillStyle = gr
          g.fillRect(0, 0, s, s)
        }
        g.fillStyle = 'rgba(60,45,10,0.5)'
        g.fillRect(0, s - 12, s, 12)
        speckle(g, s, r, 800)
      })
    case 'backFloor':
      return make(kind, 256, (g, s, r) => {
        g.fillStyle = '#7d6c2c'
        g.fillRect(0, 0, s, s)
        speckle(g, s, r, 2500, true, 0.35)
        speckle(g, s, r, 1500, false, 0.18)
        for (let i = 0; i < 4; i++) {
          const gr = g.createRadialGradient(r() * s, r() * s, 2, r() * s, r() * s, 70)
          gr.addColorStop(0, 'rgba(30,25,5,0.4)')
          gr.addColorStop(1, 'rgba(30,25,5,0)')
          g.fillStyle = gr
          g.fillRect(0, 0, s, s)
        }
      })
    case 'backCeil':
      return make(kind, 256, (g, s, r) => {
        g.fillStyle = '#d7d0a3'
        g.fillRect(0, 0, s, s)
        g.strokeStyle = 'rgba(90,80,40,0.6)'
        g.lineWidth = 3
        g.strokeRect(0, 0, s, s)
        g.strokeRect(s / 2, 0, 1, s)
        speckle(g, s, r, 1500)
      })
    case 'manWall':
      return make(kind, 256, (g, s, r) => {
        g.fillStyle = '#3d0f16'
        g.fillRect(0, 0, s, s)
        // damask diamonds
        g.fillStyle = 'rgba(120,35,45,0.5)'
        for (let y = 0; y < s * 0.62; y += 32) {
          for (let x = 0; x < s; x += 32) {
            const ox = (y / 32) % 2 ? 16 : 0
            g.beginPath()
            g.moveTo(x + ox + 16, y + 4)
            g.lineTo(x + ox + 26, y + 16)
            g.lineTo(x + ox + 16, y + 28)
            g.lineTo(x + ox + 6, y + 16)
            g.closePath()
            g.fill()
          }
        }
        // wood wainscot
        const top = s * 0.64
        g.fillStyle = '#2a170d'
        g.fillRect(0, top, s, s - top)
        g.fillStyle = '#1a0d06'
        g.fillRect(0, top - 4, s, 6)
        g.strokeStyle = '#14090400'
        g.strokeStyle = 'rgba(0,0,0,0.6)'
        g.lineWidth = 3
        for (let x = 8; x < s; x += 64) g.strokeRect(x, top + 12, 48, s - top - 24)
        speckle(g, s, r, 1200)
      })
    case 'manFloor':
      return make(kind, 256, (g, s, r) => {
        g.fillStyle = '#3a2314'
        g.fillRect(0, 0, s, s)
        for (let y = 0; y < s; y += 32) {
          g.fillStyle = `rgba(${20 + r() * 40},${10 + r() * 20},5,0.5)`
          g.fillRect(0, y, s, 30)
          g.fillStyle = 'rgba(0,0,0,0.7)'
          g.fillRect(0, y + 30, s, 2)
          const off = r() * s
          g.fillRect(off, y, 2, 30)
        }
        speckle(g, s, r, 1500, true, 0.3)
      })
    case 'manCeil':
      return make(kind, 128, (g, s, r) => {
        g.fillStyle = '#1b1411'
        g.fillRect(0, 0, s, s)
        g.strokeStyle = 'rgba(0,0,0,0.6)'
        g.lineWidth = 4
        g.strokeRect(0, 0, s, s)
        speckle(g, s, r, 400)
      })
    case 'shipWall':
      return make(kind, 256, (g, s, r) => {
        g.fillStyle = '#313c4a'
        g.fillRect(0, 0, s, s)
        g.fillStyle = '#3d4a5b'
        g.fillRect(6, 6, s / 2 - 10, s - 12)
        g.fillRect(s / 2 + 4, 6, s / 2 - 10, s - 12)
        g.fillStyle = '#4af0d6'
        g.fillRect(0, s * 0.45, s, 5)
        g.fillStyle = 'rgba(74,240,214,0.25)'
        g.fillRect(0, s * 0.45 - 4, s, 13)
        g.fillStyle = '#16202b'
        for (const [x, y] of [[14, 14], [s / 2 - 14, 14], [14, s - 14], [s / 2 - 14, s - 14], [s / 2 + 14, 14], [s - 14, 14], [s / 2 + 14, s - 14], [s - 14, s - 14]]) {
          g.beginPath()
          g.arc(x, y, 3, 0, 7)
          g.fill()
        }
        // hazard
        for (let x = 0; x < s; x += 24) {
          g.fillStyle = x % 48 === 0 ? '#d9b227' : '#111'
          g.beginPath()
          g.moveTo(x, s - 4)
          g.lineTo(x + 24, s - 4)
          g.lineTo(x + 12, s - 22)
          g.lineTo(x - 12, s - 22)
          g.fill()
        }
        speckle(g, s, r, 900)
      })
    case 'shipFloor':
      return make(kind, 256, (g, s, r) => {
        g.fillStyle = '#10161d'
        g.fillRect(0, 0, s, s)
        g.strokeStyle = '#2c3a48'
        g.lineWidth = 2
        for (let i = 0; i <= s; i += 16) {
          g.beginPath()
          g.moveTo(i, 0)
          g.lineTo(i, s)
          g.moveTo(0, i)
          g.lineTo(s, i)
          g.stroke()
        }
        g.fillStyle = 'rgba(80,255,200,0.06)'
        for (let i = 0; i < 40; i++) g.fillRect(Math.floor(r() * 16) * 16 + 3, Math.floor(r() * 16) * 16 + 3, 10, 10)
        speckle(g, s, r, 800)
      })
    case 'shipCeil':
      return make(kind, 256, (g, s, r) => {
        g.fillStyle = '#1b222b'
        g.fillRect(0, 0, s, s)
        g.fillStyle = '#2d3743'
        for (let x = 20; x < s; x += 80) {
          g.fillRect(x, 0, 22, s)
          g.fillStyle = '#4c5a69'
          g.fillRect(x + 3, 0, 4, s)
          g.fillStyle = '#2d3743'
        }
        speckle(g, s, r, 600)
      })
    case 'wood':
      return make(kind, 128, (g, s, r) => {
        g.fillStyle = '#4a2c17'
        g.fillRect(0, 0, s, s)
        for (let y = 0; y < s; y += 3) {
          g.fillStyle = `rgba(${r() * 40},${r() * 20},0,${0.25 + r() * 0.2})`
          g.fillRect(0, y, s, 1 + r() * 2)
        }
      })
    case 'crate':
      return make(kind, 128, (g, s) => {
        g.fillStyle = '#5b6a52'
        g.fillRect(0, 0, s, s)
        g.strokeStyle = '#2a3326'
        g.lineWidth = 8
        g.strokeRect(4, 4, s - 8, s - 8)
        g.lineWidth = 6
        g.beginPath()
        g.moveTo(8, 8)
        g.lineTo(s - 8, s - 8)
        g.moveTo(s - 8, 8)
        g.lineTo(8, s - 8)
        g.stroke()
        g.fillStyle = '#4af0d6'
        g.fillRect(s / 2 - 10, s / 2 - 3, 20, 6)
      })
    case 'pillar':
      return make(kind, 128, (g, s, r) => {
        g.fillStyle = '#b39f4f'
        g.fillRect(0, 0, s, s)
        g.fillStyle = 'rgba(0,0,0,0.25)'
        g.fillRect(0, s - 14, s, 14)
        speckle(g, s, r, 400)
      })
    case 'bookshelf':
      return make(kind, 128, (g, s, r) => {
        g.fillStyle = '#25140a'
        g.fillRect(0, 0, s, s)
        for (let row = 0; row < 6; row++) {
          const y = row * (s / 6)
          let x = 4
          while (x < s - 8) {
            const w = 5 + r() * 8
            g.fillStyle = `hsl(${r() * 360},40%,${18 + r() * 18}%)`
            g.fillRect(x, y + 4, w, s / 6 - 6)
            x += w + 1
          }
          g.fillStyle = '#120a05'
          g.fillRect(0, y + s / 6 - 3, s, 3)
        }
      })
    case 'alienFlesh':
      return make(kind, 128, (g, s, r) => {
        g.fillStyle = '#1f3a2a'
        g.fillRect(0, 0, s, s)
        for (let i = 0; i < 40; i++) {
          g.strokeStyle = `rgba(120,255,160,${r() * 0.4})`
          g.lineWidth = 1 + r() * 2
          g.beginPath()
          g.moveTo(r() * s, r() * s)
          g.bezierCurveTo(r() * s, r() * s, r() * s, r() * s, r() * s, r() * s)
          g.stroke()
        }
      })
  }
}

export function makePaintingTexture(seed: number): THREE.CanvasTexture {
  const c = document.createElement('canvas')
  c.width = 128
  c.height = 160
  const g = c.getContext('2d')!
  const r = rng(seed * 977 + 13)
  g.fillStyle = '#120c08'
  g.fillRect(0, 0, 128, 160)
  const gr = g.createLinearGradient(0, 0, 0, 160)
  gr.addColorStop(0, `hsl(${20 + r() * 20},25%,16%)`)
  gr.addColorStop(1, '#050303')
  g.fillStyle = gr
  g.fillRect(10, 10, 108, 140)
  // sinister portrait
  g.fillStyle = '#c9b49a'
  g.beginPath()
  g.ellipse(64, 70, 24, 32, 0, 0, 7)
  g.fill()
  g.fillStyle = '#0b0707'
  g.beginPath()
  g.ellipse(54, 64, 5, 7, 0, 0, 7)
  g.ellipse(74, 64, 5, 7, 0, 0, 7)
  g.fill()
  g.fillStyle = '#6b0d10'
  g.fillRect(52, 88, 24, 3)
  g.fillStyle = '#1a1210'
  g.fillRect(34, 104, 60, 46)
  g.strokeStyle = '#6a4a1c'
  g.lineWidth = 8
  g.strokeRect(4, 4, 120, 152)
  const t = new THREE.CanvasTexture(c)
  t.colorSpace = THREE.SRGBColorSpace
  return t
}

/** Build a box geometry with UVs scaled so textures tile by world size. */
export function tiledBox(w: number, h: number, d: number, tu: number, tv: number): THREE.BoxGeometry {
  const geo = new THREE.BoxGeometry(w, h, d)
  const uv = geo.attributes.uv as THREE.BufferAttribute
  const dims: [number, number][] = [
    [d, h], [d, h], [w, d], [w, d], [w, h], [w, h],
  ]
  for (let f = 0; f < 6; f++) {
    const [a, b] = dims[f]
    for (let i = 0; i < 4; i++) {
      const idx = f * 4 + i
      const isTop = f === 2 || f === 3
      uv.setXY(idx, (uv.getX(idx) * a) / tu, (uv.getY(idx) * b) / (isTop ? tu : tv))
    }
  }
  uv.needsUpdate = true
  return geo
}
