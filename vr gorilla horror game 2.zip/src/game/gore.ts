import * as THREE from 'three'
import type { Gorilla } from './gorilla'
import type { NavGrid } from './nav'

const MAX_P = 800
const MAX_D = 450
const MAX_GIBS = 70

interface Gib {
  obj: THREE.Object3D
  vel: THREE.Vector3
  spin: THREE.Vector3
  trail: number
  radius: number
  rest: boolean
}

const bloodColors = [0x7a0508, 0x9a0a0e, 0x5a0306, 0xb0101a, 0x3d0204]

export class GoreSystem {
  group = new THREE.Group()
  enabled = true
  private pMesh: THREE.InstancedMesh
  private pPos = new Float32Array(MAX_P * 3)
  private pVel = new Float32Array(MAX_P * 3)
  private pLife = new Float32Array(MAX_P)
  private pSize = new Float32Array(MAX_P)
  private pNext = 0
  private dMesh: THREE.InstancedMesh
  private dNext = 0
  private gibs: Gib[] = []
  private dummy = new THREE.Object3D()
  private nav: NavGrid | null = null
  private fleshMat = new THREE.MeshStandardMaterial({ color: 0x8e0f14, roughness: 0.25, metalness: 0.1 })
  private organMat = new THREE.MeshStandardMaterial({ color: 0xb02a3a, roughness: 0.2 })
  private boneMat = new THREE.MeshStandardMaterial({ color: 0xe6dcc0, roughness: 0.5 })
  private sphereGeo = new THREE.SphereGeometry(1, 12, 9)
  private capGeo = new THREE.CapsuleGeometry(1, 1, 3, 8)

  constructor() {
    const pg = new THREE.SphereGeometry(1, 5, 4)
    this.pMesh = new THREE.InstancedMesh(pg, new THREE.MeshLambertMaterial({ color: 0xffffff }), MAX_P)
    this.pMesh.frustumCulled = false
    const dg = new THREE.CircleGeometry(0.5, 12)
    dg.rotateX(-Math.PI / 2)
    const dm = new THREE.MeshLambertMaterial({ color: 0xffffff, transparent: true, opacity: 0.92, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 })
    this.dMesh = new THREE.InstancedMesh(dg, dm, MAX_D)
    this.dMesh.frustumCulled = false
    const c = new THREE.Color()
    for (let i = 0; i < MAX_P; i++) {
      this.pMesh.setColorAt(i, c.setHex(bloodColors[i % bloodColors.length]))
      this.dummy.scale.setScalar(0)
      this.dummy.updateMatrix()
      this.pMesh.setMatrixAt(i, this.dummy.matrix)
    }
    for (let i = 0; i < MAX_D; i++) {
      this.dMesh.setColorAt(i, c.setHex(bloodColors[(i * 3) % bloodColors.length]))
      this.dummy.scale.setScalar(0)
      this.dummy.updateMatrix()
      this.dMesh.setMatrixAt(i, this.dummy.matrix)
    }
    this.group.add(this.pMesh, this.dMesh)
  }

  setNav(n: NavGrid) {
    this.nav = n
  }

  clear() {
    this.pLife.fill(0)
    for (let i = 0; i < MAX_P; i++) {
      this.dummy.scale.setScalar(0)
      this.dummy.updateMatrix()
      this.pMesh.setMatrixAt(i, this.dummy.matrix)
    }
    for (let i = 0; i < MAX_D; i++) {
      this.dummy.scale.setScalar(0)
      this.dummy.updateMatrix()
      this.dMesh.setMatrixAt(i, this.dummy.matrix)
    }
    this.pMesh.instanceMatrix.needsUpdate = true
    this.dMesh.instanceMatrix.needsUpdate = true
    this.gibs.forEach((g) => this.group.remove(g.obj))
    this.gibs = []
  }

  decal(x: number, z: number, size: number) {
    if (!this.enabled) return
    const i = this.dNext++ % MAX_D
    this.dummy.position.set(x, 0.012 + (i % 7) * 0.0015, z)
    this.dummy.rotation.set(0, Math.random() * 6.28, 0)
    this.dummy.scale.set(size * (0.6 + Math.random() * 0.8), 1, size * (0.6 + Math.random() * 0.8))
    this.dummy.updateMatrix()
    this.dMesh.setMatrixAt(i, this.dummy.matrix)
    this.dMesh.instanceMatrix.needsUpdate = true
  }

  /** Spray of blood particles. */
  burst(pos: THREE.Vector3, n: number, power: number, up = 1.0, dir?: THREE.Vector3) {
    if (!this.enabled) return
    for (let k = 0; k < n; k++) {
      const i = this.pNext++ % MAX_P
      const a = Math.random() * Math.PI * 2
      const sp = Math.random() * power
      const v = new THREE.Vector3(Math.cos(a) * sp, (Math.random() * 0.7 + 0.3) * power * up, Math.sin(a) * sp)
      if (dir) v.addScaledVector(dir, power * 0.8 * Math.random())
      this.pPos.set([pos.x + (Math.random() - 0.5) * 0.2, pos.y + (Math.random() - 0.5) * 0.2, pos.z + (Math.random() - 0.5) * 0.2], i * 3)
      this.pVel.set([v.x, v.y, v.z], i * 3)
      this.pLife[i] = 1.2 + Math.random() * 2
      this.pSize[i] = 0.015 + Math.random() * 0.04
    }
  }

  /** Full gorilla gib explosion. */
  explode(g: Gorilla, dir?: THREE.Vector3) {
    if (!this.enabled) return
    const s = g.scale
    g.root.updateMatrixWorld(true)
    const center = new THREE.Vector3()
    g.root.getWorldPosition(center)
    center.y += 1.0 * s
    this.burst(center, 160, 6.5 * Math.sqrt(s), 1.0, dir)
    for (let i = 0; i < 14; i++) this.decal(center.x + (Math.random() - 0.5) * 2.5, center.z + (Math.random() - 0.5) * 2.5, 0.5 + Math.random() * 1.1)
    this.decal(center.x, center.z, 2.2 * s)

    const spawn = (obj: THREE.Object3D, r: number, pos: THREE.Vector3, power = 1) => {
      obj.position.copy(pos)
      const v = new THREE.Vector3((Math.random() - 0.5) * 6, 2.5 + Math.random() * 5, (Math.random() - 0.5) * 6).multiplyScalar(power)
      if (dir) v.addScaledVector(dir, 4)
      obj.rotation.set(Math.random() * 6, Math.random() * 6, Math.random() * 6)
      this.group.add(obj)
      this.gibs.push({ obj, vel: v, spin: new THREE.Vector3((Math.random() - 0.5) * 14, (Math.random() - 0.5) * 14, (Math.random() - 0.5) * 14), trail: 0, radius: r, rest: false })
      while (this.gibs.length > MAX_GIBS) {
        const old = this.gibs.shift()!
        this.group.remove(old.obj)
      }
    }
    const jitter = (y: number) => center.clone().add(new THREE.Vector3((Math.random() - 0.5) * 0.4, y - 1.0 * s + 0.0, (Math.random() - 0.5) * 0.4))

    // head
    const head = g.head.clone(true)
    head.scale.setScalar(s)
    head.rotation.set(0, 0, 0)
    const stump = new THREE.Mesh(this.sphereGeo, this.fleshMat)
    stump.scale.set(0.13, 0.09, 0.13)
    stump.position.set(0, -0.17, -0.05)
    head.add(stump)
    const hp = new THREE.Vector3()
    g.head.getWorldPosition(hp)
    const hw = new THREE.Group()
    hw.add(head)
    spawn(hw, 0.22 * s, hp, 1.1)

    // arms
    for (let k = 0; k < 2; k++) {
      const arm = new THREE.Group()
      const bone = new THREE.Mesh(new THREE.CylinderGeometry(0.15 * s, 0.13 * s, 1.0 * s, 8), g.furMat)
      const cap = new THREE.Mesh(this.sphereGeo, this.fleshMat)
      cap.scale.set(0.15 * s, 0.06 * s, 0.15 * s)
      cap.position.y = 0.5 * s
      const boneEnd = new THREE.Mesh(new THREE.CylinderGeometry(0.03 * s, 0.03 * s, 0.25 * s, 6), this.boneMat)
      boneEnd.position.y = 0.6 * s
      const fist = new THREE.Mesh(this.sphereGeo, g.skinMat)
      fist.scale.set(0.16 * s, 0.14 * s, 0.17 * s)
      fist.position.y = -0.55 * s
      arm.add(bone, cap, boneEnd, fist)
      spawn(arm, 0.3 * s, jitter(1.3 * s), 1.2)
    }
    // legs
    for (let k = 0; k < 2; k++) {
      const leg = new THREE.Group()
      const th = new THREE.Mesh(this.capGeo, g.furMat)
      th.scale.set(0.17 * s, 0.35 * s, 0.17 * s)
      const cap = new THREE.Mesh(this.sphereGeo, this.fleshMat)
      cap.scale.set(0.15 * s, 0.05 * s, 0.15 * s)
      cap.position.y = 0.38 * s
      const foot = new THREE.Mesh(this.sphereGeo, g.skinMat)
      foot.scale.set(0.12 * s, 0.07 * s, 0.19 * s)
      foot.position.set(0, -0.45 * s, 0.05)
      leg.add(th, cap, foot)
      spawn(leg, 0.3 * s, jitter(0.6 * s), 1)
    }
    // torso chunk(s)
    for (let k = 0; k < 2; k++) {
      const torso = new THREE.Group()
      const body = new THREE.Mesh(this.sphereGeo, g.furMat)
      body.scale.set(0.38 * s, 0.34 * s, 0.34 * s)
      const wound = new THREE.Mesh(this.sphereGeo, this.fleshMat)
      wound.scale.set(0.3 * s, 0.1 * s, 0.3 * s)
      wound.position.set(0, 0.28 * s, 0.05)
      const spine = new THREE.Mesh(new THREE.CylinderGeometry(0.03 * s, 0.03 * s, 0.5 * s, 6), this.boneMat)
      spine.position.set(0, 0.35 * s, 0)
      torso.add(body, wound, spine)
      spawn(torso, 0.35 * s, jitter(1.0 * s), 0.8)
    }
    // organs & bones
    for (let k = 0; k < 8; k++) {
      const m = new THREE.Mesh(k % 3 === 0 ? this.capGeo : this.sphereGeo, k % 2 ? this.organMat : this.fleshMat)
      const sc = 0.06 + Math.random() * 0.08
      m.scale.set(sc, sc * (k % 3 === 0 ? 2 : 1), sc)
      spawn(m, sc, jitter(1.0 * s), 1.4)
    }
    for (let k = 0; k < 4; k++) {
      const b = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 0.3 + Math.random() * 0.3, 5), this.boneMat)
      spawn(b, 0.1, jitter(1.0 * s), 1.4)
    }
  }

  update(dt: number) {
    // particles
    let any = false
    const d = this.dummy
    for (let i = 0; i < MAX_P; i++) {
      if (this.pLife[i] <= 0) continue
      any = true
      this.pLife[i] -= dt
      const o = i * 3
      this.pVel[o + 1] -= 9.8 * dt
      this.pPos[o] += this.pVel[o] * dt
      this.pPos[o + 1] += this.pVel[o + 1] * dt
      this.pPos[o + 2] += this.pVel[o + 2] * dt
      let dead = this.pLife[i] <= 0
      if (this.pPos[o + 1] < 0.02) {
        if (Math.random() < 0.5 && this.pSize[i] > 0.02) this.decal(this.pPos[o], this.pPos[o + 2], 0.12 + this.pSize[i] * 6)
        dead = true
      }
      if (this.nav && this.nav.wallAt(this.pPos[o], this.pPos[o + 2])) {
        this.pVel[o] *= -0.2
        this.pVel[o + 2] *= -0.2
        dead = true
      }
      if (dead) {
        this.pLife[i] = 0
        d.scale.setScalar(0)
      } else {
        d.position.set(this.pPos[o], this.pPos[o + 1], this.pPos[o + 2])
        d.scale.set(this.pSize[i], this.pSize[i] * 1.3, this.pSize[i])
      }
      d.rotation.set(0, 0, 0)
      d.updateMatrix()
      this.pMesh.setMatrixAt(i, d.matrix)
    }
    if (any) this.pMesh.instanceMatrix.needsUpdate = true

    // gibs
    for (const gb of this.gibs) {
      if (gb.rest) continue
      gb.vel.y -= 9.8 * dt
      const p = gb.obj.position
      p.addScaledVector(gb.vel, dt)
      gb.obj.rotation.x += gb.spin.x * dt
      gb.obj.rotation.y += gb.spin.y * dt
      gb.obj.rotation.z += gb.spin.z * dt
      if (this.nav && this.nav.wallAt(p.x, p.z)) {
        p.addScaledVector(gb.vel, -dt)
        gb.vel.x *= -0.4
        gb.vel.z *= -0.4
      }
      const floor = gb.radius * 0.7
      if (p.y < floor) {
        p.y = floor
        const sp = Math.abs(gb.vel.y)
        if (sp > 1.5) {
          this.decal(p.x, p.z, 0.4 + sp * 0.12)
          this.burst(p, 6, 2.5)
        }
        gb.vel.y = sp > 1.2 ? sp * 0.3 : 0
        gb.vel.x *= 0.7
        gb.vel.z *= 0.7
        gb.spin.multiplyScalar(0.6)
        if (sp <= 1.2 && Math.hypot(gb.vel.x, gb.vel.z) < 0.3) {
          gb.rest = true
          this.decal(p.x, p.z, 0.5 + gb.radius * 2)
        }
      }
      gb.trail -= dt
      if (gb.trail <= 0 && gb.vel.length() > 1.5) {
        gb.trail = 0.07
        this.burst(p, 2, 0.8, 0.2)
      }
    }
  }
}
