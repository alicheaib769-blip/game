export class AudioSys {
  ctx: AudioContext | null = null
  master!: GainNode
  noiseBuf!: AudioBuffer
  ambient: { stop: () => void } | null = null
  enabled = true

  init() {
    if (this.ctx) {
      this.ctx.resume()
      return
    }
    try {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext
      this.ctx = new AC()
    } catch {
      return
    }
    const ctx = this.ctx
    this.master = ctx.createGain()
    this.master.gain.value = 0.7
    const comp = ctx.createDynamicsCompressor()
    this.master.connect(comp)
    comp.connect(ctx.destination)
    const len = ctx.sampleRate * 2
    this.noiseBuf = ctx.createBuffer(1, len, ctx.sampleRate)
    const d = this.noiseBuf.getChannelData(0)
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1
  }

  private noise(dur: number, freq: number, q: number, vol: number, type: BiquadFilterType = 'lowpass', when = 0, sweepTo?: number) {
    const ctx = this.ctx
    if (!ctx) return
    const src = ctx.createBufferSource()
    src.buffer = this.noiseBuf
    const f = ctx.createBiquadFilter()
    f.type = type
    f.frequency.value = freq
    f.Q.value = q
    if (sweepTo) f.frequency.exponentialRampToValueAtTime(sweepTo, ctx.currentTime + when + dur)
    const g = ctx.createGain()
    const t = ctx.currentTime + when
    g.gain.setValueAtTime(0, t)
    g.gain.linearRampToValueAtTime(vol, t + 0.01)
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur)
    src.connect(f)
    f.connect(g)
    g.connect(this.master)
    src.start(t, Math.random())
    src.stop(t + dur + 0.05)
  }

  private tone(freq: number, dur: number, vol: number, type: OscillatorType = 'sine', when = 0, endFreq?: number) {
    const ctx = this.ctx
    if (!ctx) return
    const o = ctx.createOscillator()
    o.type = type
    const t = ctx.currentTime + when
    o.frequency.setValueAtTime(freq, t)
    if (endFreq) o.frequency.exponentialRampToValueAtTime(endFreq, t + dur)
    const g = ctx.createGain()
    g.gain.setValueAtTime(0, t)
    g.gain.linearRampToValueAtTime(vol, t + 0.02)
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur)
    o.connect(g)
    g.connect(this.master)
    o.start(t)
    o.stop(t + dur + 0.05)
  }

  thump(vol = 0.5, pitch = 1) {
    this.tone(90 * pitch, 0.14, vol, 'sine', 0, 40)
    this.noise(0.08, 300, 1, vol * 0.5)
  }
  splat() {
    this.noise(0.35, 900, 2, 0.8, 'lowpass', 0, 120)
    this.noise(0.2, 2500, 4, 0.35, 'bandpass', 0.02)
    this.tone(70, 0.3, 0.5, 'sine', 0, 30)
  }
  crunch() {
    for (let i = 0; i < 4; i++) this.noise(0.07, 1500 + Math.random() * 1500, 3, 0.6, 'bandpass', i * 0.05)
  }
  growl(vol = 0.6, pitch = 1) {
    this.tone(70 * pitch, 0.9, vol, 'sawtooth', 0, 45 * pitch)
    this.tone(73 * pitch, 0.9, vol * 0.7, 'square', 0, 48 * pitch)
    this.noise(0.9, 400, 2, vol * 0.5, 'bandpass', 0, 200)
  }
  roar(vol = 0.9) {
    this.tone(110, 1.6, vol, 'sawtooth', 0, 55)
    this.tone(165, 1.4, vol * 0.5, 'square', 0.05, 70)
    this.noise(1.6, 900, 1.5, vol * 0.8, 'bandpass', 0, 250)
  }
  screech() {
    this.tone(900, 0.5, 0.35, 'sawtooth', 0, 2200)
    this.noise(0.6, 3000, 1, 0.3, 'highpass')
  }
  squeak(vol = 0.5, pitch = 1) {
    this.tone(1300 * pitch, 0.14, vol * 0.5, 'sawtooth', 0, 2200 * pitch)
    this.tone(1700 * pitch, 0.1, vol * 0.4, 'square', 0.09, 2600 * pitch)
    this.noise(0.12, 4000, 2, vol * 0.25, 'highpass')
  }
  slam() {
    this.tone(60, 0.5, 0.95, 'sine', 0, 24)
    this.noise(0.4, 250, 1, 0.85, 'lowpass', 0, 60)
    this.noise(0.25, 900, 2, 0.4, 'bandpass', 0.05, 200)
    this.crunch()
  }
  pin() {
    this.tone(320, 0.25, 0.5, 'square', 0, 160)
    this.noise(0.3, 700, 2, 0.4, 'bandpass', 0, 250)
  }
  tagPop() {
    this.tone(520, 0.1, 0.35, 'triangle')
    this.tone(880, 0.16, 0.3, 'triangle', 0.08)
  }
  heartbeat(vol = 0.6) {
    this.tone(60, 0.16, vol, 'sine', 0, 38)
    this.tone(55, 0.18, vol * 0.8, 'sine', 0.17, 35)
  }
  pickup() {
    this.tone(660, 0.12, 0.3, 'triangle')
    this.tone(990, 0.18, 0.3, 'triangle', 0.1)
    this.tone(1320, 0.25, 0.25, 'triangle', 0.2)
  }
  alarm() {
    for (let i = 0; i < 3; i++) this.tone(520, 0.3, 0.3, 'square', i * 0.4, 380)
  }
  win() {
    ;[523, 659, 784, 1047].forEach((f, i) => this.tone(f, 0.4, 0.3, 'triangle', i * 0.14))
  }
  lose() {
    ;[300, 250, 200, 140].forEach((f, i) => this.tone(f, 0.7, 0.35, 'sawtooth', i * 0.25))
  }

  startAmbient(kind: 'backrooms' | 'mansion' | 'ship') {
    this.stopAmbient()
    const ctx = this.ctx
    if (!ctx) return
    const nodes: AudioScheduledSourceNode[] = []
    const out = ctx.createGain()
    out.gain.value = 0.25
    out.connect(this.master)
    const osc = (type: OscillatorType, f: number, v: number, dest: AudioNode = out) => {
      const o = ctx.createOscillator()
      o.type = type
      o.frequency.value = f
      const g = ctx.createGain()
      g.gain.value = v
      o.connect(g)
      g.connect(dest)
      o.start()
      nodes.push(o)
      return o
    }
    const loopNoise = (freq: number, v: number, type: BiquadFilterType = 'lowpass') => {
      const s = ctx.createBufferSource()
      s.buffer = this.noiseBuf
      s.loop = true
      const f = ctx.createBiquadFilter()
      f.type = type
      f.frequency.value = freq
      const g = ctx.createGain()
      g.gain.value = v
      s.connect(f)
      f.connect(g)
      g.connect(out)
      s.start()
      nodes.push(s)
      return f
    }
    let timer = 0
    if (kind === 'backrooms') {
      osc('sawtooth', 60, 0.18)
      osc('sine', 120, 0.25)
      osc('square', 180.4, 0.03)
      loopNoise(500, 0.05)
    } else if (kind === 'mansion') {
      osc('sine', 48, 0.4)
      osc('triangle', 72.5, 0.12)
      const f = loopNoise(500, 0.35)
      const lfo = osc('sine', 0.12, 250, f.frequency as unknown as AudioNode)
      void lfo
      timer = window.setInterval(() => {
        if (Math.random() < 0.4) this.tone(180 + Math.random() * 80, 2.5, 0.05, 'sine', 0, 160)
        else this.noise(0.5, 200, 2, 0.4, 'lowpass')
      }, 7000)
    } else {
      osc('sine', 40, 0.5)
      osc('sawtooth', 55, 0.08)
      const g2 = osc('sine', 0.25, 0.2, out.gain as unknown as AudioNode)
      void g2
      loopNoise(900, 0.06, 'bandpass')
      timer = window.setInterval(() => this.tone(1800 + Math.random() * 1500, 0.08, 0.05, 'sine'), 2200)
    }
    this.ambient = {
      stop: () => {
        nodes.forEach((n) => {
          try {
            n.stop()
          } catch {
            /* */
          }
        })
        out.disconnect()
        if (timer) clearInterval(timer)
      },
    }
  }
  stopAmbient() {
    this.ambient?.stop()
    this.ambient = null
  }
}
